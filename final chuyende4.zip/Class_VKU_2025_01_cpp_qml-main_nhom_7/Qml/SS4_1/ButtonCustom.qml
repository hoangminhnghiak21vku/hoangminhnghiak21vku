import QtQuick 2.15
import QtQuick.Controls 2.15

Button {
    width: 50
    height: 50
    font.pixelSize: 20
    background: Rectangle {
        color: "#3498db"
        radius: 8
        border.color: "#2980b9"
    }
    contentItem: Text {
        text: parent.text
        font.bold: true
        color: "white"
        anchors.centerIn: parent
    }
}
