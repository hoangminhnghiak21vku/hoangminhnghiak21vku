import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    width: 250
    height: 300
    color: "#f4f4f4"
    radius: 10
    border.color: "#ccc"

    Column {
        anchors.centerIn: parent
        spacing: 10

        TextField {
            id: input1
            width: parent.width - 20
            height: 40
            placeholderText: "Enter first number"
        }

        TextField {
            id: input2
            width: parent.width - 20
            height: 40
            placeholderText: "Enter second number"
        }

        Text {
            id: result
            width: parent.width
            height: 30
            text: "Result: "
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
        }

        Row {
            spacing: 10
            anchors.horizontalCenter: parent.horizontalCenter

            ButtonCustom {
                text: "+"
                onClicked: calculate("+")
            }

            ButtonCustom {
                text: "-"
                onClicked: calculate("-")
            }

            ButtonCustom {
                text: "×"
                onClicked: calculate("*")
            }

            ButtonCustom {
                text: "÷"
                onClicked: calculate("/")
            }
        }
    }

    function calculate(operator) {
        var num1 = parseFloat(input1.text);
        var num2 = parseFloat(input2.text);

        if (isNaN(num1) || isNaN(num2)) {
            result.text = "Result: Invalid input";
            return;
        }

        switch (operator) {
            case "+": result.text = "Result: " + (num1 + num2); break;
            case "-": result.text = "Result: " + (num1 - num2); break;
            case "*": result.text = "Result: " + (num1 * num2); break;
            case "/": result.text = num2 !== 0 ? "Result: " + (num1 / num2) : "Result: Cannot divide by zero"; break;
        }
    }
}
