import QtQuick 2.15
import QtQuick.Window 2.15
import "."
Window {
    width: 500
    height: 500
    visible: true
    title: qsTr("Mini Calculator")

    Calculator {
        anchors.centerIn:parent
    }

}
