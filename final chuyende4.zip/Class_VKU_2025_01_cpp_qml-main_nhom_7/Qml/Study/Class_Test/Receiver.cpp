#include "Receiver.h"
#include <QDebug>

Receiver::Receiver(QObject *parent) : QObject(parent) {}

void Receiver::receiveData(int value) {
    qDebug() << "Received value:" << value;
}
