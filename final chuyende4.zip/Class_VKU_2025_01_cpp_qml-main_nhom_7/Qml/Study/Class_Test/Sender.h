#ifndef SENDER_H
#define SENDER_H

#include <QObject>

class Sender : public QObject {
    Q_OBJECT

public:
    explicit Sender(QObject *parent = nullptr);

signals:
    void sendData(int value);

public slots:
    void triggerSignal();
};

#endif // SENDER_H

