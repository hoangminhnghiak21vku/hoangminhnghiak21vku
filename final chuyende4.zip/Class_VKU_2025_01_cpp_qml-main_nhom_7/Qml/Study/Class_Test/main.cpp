#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "Sender.h"
#include "Receiver.h"
int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    Sender sender;
    Receiver receiver;

    // Kết nối signal từ Sender đến slot của Receiver
    QObject::connect(&sender, &Sender::sendData, &receiver, &Receiver::receiveData);

    // Phát tín hiệu
    sender.triggerSignal();

    return app.exec();
}
