#include "Sender.h"
#include <QDebug>
Sender::Sender(QObject *parent) : QObject(parent) {}

void Sender::triggerSignal() {
    int value = 40;
    emit sendData(value);

     qDebug() << "Signal emitted with value:" << value;

}






