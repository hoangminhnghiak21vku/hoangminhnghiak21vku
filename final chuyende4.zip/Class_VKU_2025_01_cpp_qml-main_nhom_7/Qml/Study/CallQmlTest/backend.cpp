#include "backend.h"
#include <QMetaObject>
#include <QVariant>

// Constructor
Backend::Backend(QObject *parent) : QObject(parent), m_message("Hello from C++") {}

QString Backend::message() const {
    return m_message;
}

void Backend::setMessage(const QString &msg) {
    if (m_message != msg) {
        m_message = msg;
        emit messageChanged();
    }
}

void Backend::showMessage(const QString &text) {
    qDebug() << "Message from QML: " << text;
}



void Backend::callQmlFunction(QObject *qmlObject) {
    if (qmlObject) {
        qDebug() << "Calling qmlFunction on object:" << qmlObject;
        bool success = QMetaObject::invokeMethod(qmlObject, "qmlFunction",
                                                 Q_ARG(QVariant, QVariant("Data from C++")));  // ✅ Đổi thành QVariant
        if (!success) {
            qDebug() << "Failed to invoke qmlFunction!";
        }
    } else {
        qDebug() << "qmlObject is NULL!";
    }
}
