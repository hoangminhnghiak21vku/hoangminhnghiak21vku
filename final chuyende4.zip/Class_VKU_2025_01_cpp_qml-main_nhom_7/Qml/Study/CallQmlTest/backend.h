#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>
#include <QDebug>

class Backend : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString message READ message WRITE setMessage NOTIFY messageChanged)

public:
    explicit Backend(QObject *parent = nullptr);

    QString message() const;
    void setMessage(const QString &msg);

    Q_INVOKABLE void showMessage(const QString &text);
    Q_INVOKABLE void callQmlFunction(QObject *qmlObject);  // Thêm Q_INVOKABLE

signals:
    void messageChanged();

private:
    QString m_message;
};

#endif // BACKEND_H
