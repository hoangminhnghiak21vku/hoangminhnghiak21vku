import QtQuick 2.15
import QtQuick.Controls 2.15

ApplicationWindow {
    visible: true
    width: 400
    height: 300

    Column {
        anchors.centerIn: parent
        spacing: 10

        Label {
            text: backend.message  // Lấy dữ liệu từ C++
        }

        Button {
            text: "Gửi tin nhắn đến C++"
            onClicked: backend.showMessage("Hello from QML")
        }

        Button {
            text: "Thay đổi Message"
            onClicked: backend.message = "Updated from QML"
        }
        Button {
            text: "Gọi hàm QML từ C++"
            onClicked: backend.callQmlFunction(Qt.application.activeWindow)  // ✅ Truyền ApplicationWindow
        }

    }


    function qmlFunction(message) {
        console.log("Called from C++:", message);
    }

    Component.onCompleted: {
        if (backend) {
            backend.callQmlFunction(this);  // ✅ Chỉ gọi nếu `backend` tồn tại
        } else {
            console.log("❌ Backend object is NULL!");
        }
    }

}
