#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "backend.h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    Backend backend;
    engine.rootContext()->setContextProperty("backend", &backend);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    // Lấy rootObject của QML (ApplicationWindow)
    QObject *rootObject = engine.rootObjects().isEmpty() ? nullptr : engine.rootObjects().first();
    if (rootObject) {
        backend.callQmlFunction(rootObject);  // ✅ Chỉ gọi khi rootObject không null
    } else {
        qDebug() << "❌ Root object is NULL! Không gọi callQmlFunction.";
    }
    return app.exec();
}
