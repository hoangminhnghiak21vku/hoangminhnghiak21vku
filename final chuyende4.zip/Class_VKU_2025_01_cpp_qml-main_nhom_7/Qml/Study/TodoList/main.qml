import QtQuick 2.15
import QtQuick.Window 2.15
import QtQuick.Controls 2.15
Window {
    width: 640
    height: 480
    visible: true
    title: qsTr("My ToDo List")
    ListModel {
        id:myModel
        ListElement {

            content:"ABC"
            isDone:false
        }
        ListElement {

            content:"XYZ"
            isDone:true
        }
    }

    ListView {
        id:myTodoList
        model:myModel
        height:parent.height
        header:Row {
            Button {
                text:"append/add"
                onClicked :{
                    myModel.append({
                    text:"",
                    isDone:false
                    })
                }
            }

        }

        delegate: Row {
            TextField {
                text:content
            }
            CheckBox {
                checked:isDone
            }
            Button {
                text:"Remove"
                onClicked: {
                    myModel.remove(index)
                }
            }
        }
    }
}
