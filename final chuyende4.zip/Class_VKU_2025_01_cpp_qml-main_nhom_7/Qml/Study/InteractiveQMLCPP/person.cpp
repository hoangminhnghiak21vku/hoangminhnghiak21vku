#include "person.h"
#include <QObject>

Person::Person(QObject *parent)
    : QObject{parent}
{}

QString Person::name()
{
    return m_name;
}

void Person::setName(QString name)
{
    m_name = name;
}

int Person::shoeSize()
{
    return m_shoeSize;
}

void Person::setShoeSize(int size)
{
    m_shoeSize = size;
}
