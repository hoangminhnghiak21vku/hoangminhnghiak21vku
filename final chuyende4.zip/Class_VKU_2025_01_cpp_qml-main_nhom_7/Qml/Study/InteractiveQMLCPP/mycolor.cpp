#include "mycolor.h"
#include <QDebug>
MyColor::MyColor(QObject *parent)
    : QObject{parent}
{
    m_colorValue = "yellow";
}

void MyColor::setColorValue(QString color)
{
    if(m_colorValue != color) {
        m_colorValue = color;
        emit colorValueChanged(color);
    }
}

QString MyColor::colorValue()
{
    return m_colorValue;
}

void MyColor::setColor(QString color)
{
    qDebug() << "" << color;
    m_colorValue = color;
    emit colorValueChanged(color);
}
