#ifndef MYCOLOR_H
#define MYCOLOR_H

#include <QObject>

class MyColor : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString colorValue READ colorValue WRITE setColorValue NOTIFY colorValueChanged FINAL)
public:
    explicit MyColor(QObject *parent = nullptr);
    void setColorValue(QString color);
    QString colorValue();
    Q_INVOKABLE void setColor(QString color);
private:
    QString m_colorValue;
signals:
    void colorValueChanged(QString colorValue);
};

#endif // MYCOLOR_H
