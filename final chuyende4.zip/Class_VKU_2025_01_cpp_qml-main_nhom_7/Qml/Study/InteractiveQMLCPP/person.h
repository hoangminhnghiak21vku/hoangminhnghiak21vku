#ifndef PERSON_H
#define PERSON_H

#include <QObject>

class Person : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString name READ name WRITE setName);
    Q_PROPERTY(int shoeSize READ shoeSize WRITE setShoeSize);
public:
    explicit Person(QObject *parent = nullptr);

    QString name();
    void setName(QString name);
    int shoeSize();
    void setShoeSize(int size);

private:
    QString m_name;
    int m_shoeSize;

};
#endif // PERSON_H
