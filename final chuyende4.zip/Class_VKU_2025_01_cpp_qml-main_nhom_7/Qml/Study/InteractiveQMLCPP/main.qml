import QtQuick 2.15
import QtQuick.Window 2.15
import com.example.mycolor 1.0
import com.example.person 1.0
Window {
    width: 640
    height: 480
    visible: true
    title: qsTr("Hello World")
    Person {
        name:"Van Tuan"
        shoeSize:30
        id :myPerson
        Component.onCompleted : {
            console.log("Person has completed");
            console.log(name);
        }
    }

    MyColor { id: myColor }  // Tạo đối tượng MyColor
    signal signalClick();
    Rectangle {
        width:200;height:100

        color:myColor.colorValue;
        MouseArea {
            anchors.fill : parent;
            onClicked: {
                signalClick()
            myColor.colorValue = "blue"
            myColor.setColor("red");
            }

        }
    }
}
