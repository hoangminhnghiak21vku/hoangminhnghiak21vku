QT += quick serialport
CONFIG += c++17

SOURCES += \
    main.cpp \
    dashboarddata.cpp \
    serialhandler.cpp

HEADERS += \
    dashboarddata.h \
    serialhandler.h

RESOURCES += qml.qrc
