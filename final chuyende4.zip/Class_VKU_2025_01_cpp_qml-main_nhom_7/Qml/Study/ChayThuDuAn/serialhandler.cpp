#include "serialhandler.h"
#include "dashboarddata.h"
#include <QDebug>

SerialHandler::SerialHandler(DashboardData* dashboard, QObject *parent)
    : QObject(parent), m_dashboard(dashboard) {
    serial = new QSerialPort(this);
}

void SerialHandler::start() {
    serial->setPortName("COM3"); // Chỉnh lại theo cổng thực tế
    serial->setBaudRate(QSerialPort::Baud115200);
    if (serial->open(QIODevice::ReadWrite)) {
        connect(serial, &QSerialPort::readyRead, this, &SerialHandler::readSerial);
        qDebug() << "Serial started on COM3";
    } else {
        qDebug() << "Cannot open serial port!";
    }
}

void SerialHandler::readSerial() {
    buffer.append(serial->readAll());

    while (buffer.contains('\n')) {
        int endIndex = buffer.indexOf('\n');
        QByteArray line = buffer.left(endIndex).trimmed();
        buffer.remove(0, endIndex + 1);

        int speed = -1, gear = -1, fuel = -1;

        const auto parts = line.split(';');
        for (const auto &part : parts) {
            if (part.startsWith("SPD:")) speed = part.mid(4).toInt();
            else if (part.startsWith("GEAR:")) gear = part.mid(5).toInt();
            else if (part.startsWith("FUEL:")) fuel = part.mid(5).toInt();
        }

        if (speed >= 0) m_dashboard->setSpeed(speed);
        if (gear >= 0) m_dashboard->setGear(gear);
        if (fuel >= 0) m_dashboard->setFuel(fuel);
    }
}

void SerialHandler::sendCommand(const QString &cmd) {
    if (serial->isOpen()) {
        QByteArray data = cmd.toUtf8() + "\n";
        serial->write(data);
        qDebug() << "Sent command:" << data;
    }
}