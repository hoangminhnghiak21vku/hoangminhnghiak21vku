#include "dashboarddata.h"

DashboardData::DashboardData(QObject *parent)
    : QObject(parent), m_speed(0), m_gear(0), m_fuel(50) {}

int DashboardData::speed() const { return m_speed; }
int DashboardData::gear() const { return m_gear; }
int DashboardData::fuel() const { return m_fuel; }

void DashboardData::setSpeed(int value) {
    if (m_speed != value) {
        m_speed = value;
        emit speedChanged();
    }
}

void DashboardData::setGear(int value) {
    if (m_gear != value) {
        m_gear = value;
        emit gearChanged();
    }
}

void DashboardData::setFuel(int value) {
    if (m_fuel != value) {
        m_fuel = value;
        emit fuelChanged();
    }
}