#ifndef SERIALHANDLER_H
#define SERIALHANDLER_H

#include <QObject>
#include <QSerialPort>

class DashboardData;

class SerialHandler : public QObject {
    Q_OBJECT

public:
    SerialHandler(DashboardData* dashboard, QObject *parent = nullptr);
    void start();

public slots:
    void sendCommand(const QString &cmd);

private slots:
    void readSerial();

private:
    QSerialPort *serial;
    DashboardData* m_dashboard;
    QByteArray buffer;
};

#endif // SERIALHANDLER_H