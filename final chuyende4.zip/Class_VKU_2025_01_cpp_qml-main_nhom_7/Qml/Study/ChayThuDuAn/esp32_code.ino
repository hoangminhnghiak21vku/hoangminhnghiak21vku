void setup() {
  Serial.begin(115200);
  pinMode(2, INPUT_PULLUP); // P
  pinMode(3, INPUT_PULLUP); // R
  pinMode(4, INPUT_PULLUP); // N
  pinMode(5, INPUT_PULLUP); // D
}

int readGear() {
  if (digitalRead(2) == LOW) return 0;
  if (digitalRead(3) == LOW) return 1;
  if (digitalRead(4) == LOW) return 2;
  if (digitalRead(5) == LOW) return 3;
  return -1;
}

void processCommand(String cmd) {
  if (cmd == "RESET_TRIP") {
    Serial.println("ACK:RESET_TRIP");
  } else if (cmd.startsWith("SET_SPEED:")) {
    int s = cmd.substring(10).toInt();
    Serial.print("ACK:SET_SPEED ");
    Serial.println(s);
  }
}

void loop() {
  int speed = map(analogRead(A0), 0, 4095, 0, 180);
  int fuel = map(analogRead(A1), 0, 4095, 0, 100);
  int gear = readGear();

  Serial.print("SPD:"); Serial.print(speed);
  Serial.print(";GEAR:"); Serial.print(gear);
  Serial.print(";FUEL:"); Serial.println(fuel);

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    processCommand(cmd);
  }

  delay(200);
}