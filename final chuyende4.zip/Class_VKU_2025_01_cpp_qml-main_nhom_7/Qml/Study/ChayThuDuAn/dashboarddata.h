#ifndef DASHBOARDDATA_H
#define DASHBOARDDATA_H

#include <QObject>

class DashboardData : public QObject {
    Q_OBJECT
    Q_PROPERTY(int speed READ speed WRITE setSpeed NOTIFY speedChanged)
    Q_PROPERTY(int gear READ gear WRITE setGear NOTIFY gearChanged)
    Q_PROPERTY(int fuel READ fuel WRITE setFuel NOTIFY fuelChanged)

public:
    explicit DashboardData(QObject *parent = nullptr);

    int speed() const;
    int gear() const;
    int fuel() const;

    void setSpeed(int value);
    void setGear(int value);
    void setFuel(int value);

signals:
    void speedChanged();
    void gearChanged();
    void fuelChanged();

private:
    int m_speed;
    int m_gear;
    int m_fuel;
};

#endif // DASHBOARDDATA_H