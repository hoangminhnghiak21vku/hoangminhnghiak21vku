#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "dashboarddata.h"
#include "serialhandler.h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    DashboardData dashboard;
    SerialHandler serial(&dashboard);
    serial.start();

    engine.rootContext()->setContextProperty("dashboardData", &dashboard);
    engine.rootContext()->setContextProperty("serialHandler", &serial);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}