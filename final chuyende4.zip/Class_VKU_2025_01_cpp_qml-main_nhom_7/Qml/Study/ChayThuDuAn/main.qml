import QtQuick 2.15
import QtQuick.Window 2.15
import QtQuick.Controls 2.15

Window {
    visible: true
    width: 480
    height: 320
    title: qsTr("Dashboard Monitor")

    Column {
        anchors.centerIn: parent
        spacing: 20

        Text {
            text: "Speed: " + dashboardData.speed + " km/h"
            font.pixelSize: 24
        }

        Text {
            text: "Gear: " + ["P", "R", "N", "D"][dashboardData.gear]
            font.pixelSize: 24
        }

        Text {
            text: "Fuel: " + dashboardData.fuel + "%"
            font.pixelSize: 24
        }

        Row {
            spacing: 10
            Button {
                text: "Reset Trip"
                onClicked: serialHandler.sendCommand("RESET_TRIP")
            }
            Button {
                text: "Set Speed 100"
                onClicked: serialHandler.sendCommand("SET_SPEED:100")
            }
        }
    }
}