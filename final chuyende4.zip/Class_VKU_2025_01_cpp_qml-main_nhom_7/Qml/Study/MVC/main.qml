import QtQuick 2.15
import QtQuick.Window 2.15

Window {
    width: 640
    height: 480
    visible: true
    title: qsTr("Hello World")

    ListView {
        id:listView
        model:myModel
        height:500
        width:500

        delegate: Rectangle {
            width:200
            height:100
            border.color:"red"
            Text {
                id:txt
                text:qsTr("") + modelData

                anchors.verticalCenter : parent.verticalCenter

            }
        }
    }
}
