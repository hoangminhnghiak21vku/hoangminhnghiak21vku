import QtQuick 2.15

Item {
    property real minValue: 0
    property real maxValue: 100
    property real value: 0

    width: 250
    height: 250
    transformOrigin: Item.Center

    Image {
        id: needle
        source: "Indicator.png"
        width: parent.width * 0.1
        height: parent.height * 0.4
        anchors.centerIn: parent
        rotation: 150 + (value / maxValue) * 240  // Góc quay từ 150° đến 390°
    }
}
