import QtQuick 2.15
import QtQuick.Controls 2.15

Item {
    property alias minValue: needle.minValue
    property alias maxValue: needle.maxValue
    property alias value: needle.value
    property alias source: background.source

    width: 250
    height: 250

    Image {
        id: background
        width: parent.width
        height: parent.height
    }

    Indicator {
        id: needle
        width: parent.width
        height: parent.height
    }
}
