#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "changedataevent.h".h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    ChangeDataEvent changeDataEvent;
    engine.rootContext()->setContextProperty("changeDataEvent", &changeDataEvent);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
