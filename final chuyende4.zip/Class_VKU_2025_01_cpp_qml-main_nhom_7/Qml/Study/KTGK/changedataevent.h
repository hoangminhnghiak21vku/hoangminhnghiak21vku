#ifndef CHANGEDATAEVENT_H
#define CHANGEDATAEVENT_H

#include <QObject>

class ChangeDataEvent : public QObject {
    Q_OBJECT
public:
    explicit ChangeDataEvent(QObject *parent = nullptr) : QObject(parent) {}

    Q_INVOKABLE void changeSpeed(int value) {
        int mappedValue = 150 + (value / 500.0) * 240; // Map từ 0-500 thành 150-390
        emit speedChanged(mappedValue);
    }

    Q_INVOKABLE void changeTacho(int value) {
        int mappedValue = 150 + (value / 500.0) * 240; // Map từ 0-500 thành 150-390
        emit tachoChanged(mappedValue);
    }

signals:
    void speedChanged(int newRotation);
    void tachoChanged(int newRotation);
};

#endif // CHANGEDATAEVENT_H
