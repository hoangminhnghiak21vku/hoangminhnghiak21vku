import QtQuick 2.15
import QtQuick.Controls 2.15

ApplicationWindow {
    visible: true
    width: 800
    height: 400
    title: "Gauge Control"

    Rectangle {
        width: parent.width
        height: parent.height
        color: "#222"

        // Đồng hồ tốc độ (SpeedMeter)
        Image {
            id: speedMeter
            source: "/n/SpeedMetter.png"
            width: parent.width * 0.4
            height: parent.height * 0.6
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
        }

        // Kim chỉ tốc độ
        Image {
            id: speedNeedle
            source: "Indicator.png"
            width: speedMeter.width * 0.1
            height: speedMeter.height * 0.4
            anchors.centerIn: speedMeter
            rotation: 150 // Góc mặc định
        }

        // Đồng hồ vòng tua (TachoMeter)
        Image {
            id: tachoMeter
            source: "/ne/TachoMetter.png"
            width: parent.width * 0.4
            height: parent.height * 0.6
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
        }

        // Kim chỉ vòng tua
        Image {
            id: tachoNeedle
            source: "Indicator.png"
            width: tachoMeter.width
            height: tachoMeter.height
            anchors.centerIn: tachoMeter
            rotation: 150 // Góc mặc định
        }

        // Slider chỉnh tốc độ (Speed)
        Slider {
            id: speedSlider
            from: 0
            to: 500
            stepSize: 1
            width: parent.width * 0.4
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            background: Rectangle {
                color: "red"
                height: 4
            }
            handle: Rectangle {
                width: 20
                height: 20
                color: "orange"
                radius: 10
            }
            onValueChanged: {
                console.log("Speed Value:", value)
                changeDataEvent.changeSpeed(value)
            }
        }

        // Slider chỉnh vòng tua (Tacho)
        Slider {
            id: tachoSlider
            from: 0
            to: 500
            stepSize: 1
            width: parent.width * 0.4
            anchors.bottom: parent.bottom
            anchors.right: parent.right
            background: Rectangle {
                color: "red"
                height: 4
            }
            handle: Rectangle {
                width: 20
                height: 20
                color: "orange"
                radius: 10
            }
            onValueChanged: {
                console.log("Tacho Value:", value)
                changeDataEvent.changeTacho(value)
            }
        }

        // Kết nối sự kiện từ C++ về QML
        Connections {
            target: changeDataEvent
            function onSpeedChanged(newRotation) {
                speedNeedle.rotation = newRotation;
                console.log("Speed Needle Rotation:", newRotation)
            }
            function onTachoChanged(newRotation) {
                tachoNeedle.rotation = newRotation;
                console.log("Tacho Needle Rotation:", newRotation)
            }
        }
    }
}
