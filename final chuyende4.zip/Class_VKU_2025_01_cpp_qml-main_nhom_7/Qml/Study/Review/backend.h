#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>

class Backend : public QObject
{
    Q_OBJECT
public:
    explicit Backend(QObject *parent = nullptr);
    void setValue(int a);
signals:
    void signalValueChanged(int value);
public slots:
    void slotHandleValueChanged(int value);
private:
    int m_value;

};


#endif // BACKEND_H
