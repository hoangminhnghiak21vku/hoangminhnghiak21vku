#include "backend.h"
#include <QDebug>
Backend::Backend(QObject *parent)
    : QObject{parent}
{
    m_value = 0;
}

void Backend::setValue(int a)
{
    if(m_value != a) {
        m_value = a;
        emit signalValueChanged(a);
    }
}

void Backend::slotHandleValueChanged(int value)
{
    qDebug() << "Slot handled with value : " << value;
}
