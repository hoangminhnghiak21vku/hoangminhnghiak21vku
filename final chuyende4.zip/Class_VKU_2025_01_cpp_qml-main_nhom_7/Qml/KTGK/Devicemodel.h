#ifndef DEVICEMODEL_H
#define DEVICEMODEL_H

#include <QAbstractListModel>
#include <QStringList>

struct Device {
    QString macId;
    QString deviceName;
};

class DeviceModel : public QAbstractListModel {
    Q_OBJECT

public:
    explicit DeviceModel(QObject *parent = nullptr);
    enum Roles {
        MacIdRole = Qt::UserRole + 1,
        DeviceNameRole
    };

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE void addDevice(const QString &macId, const QString &deviceName);

private:
    QList<Device> devices;
};

#endif // DEVICEMODEL_H
