import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    id: root
    width: 64
    height: 34
    color: "orange"
    radius: height / 2

    signal clicked()

    MouseArea {
        anchors.fill: parent
        onClicked: root.clicked()
    }
}
