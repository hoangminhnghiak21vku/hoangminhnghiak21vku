import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    id: root
    width: 400
    height: 50
    color: "white"
    border.color: "gray"
    radius: 5

    property alias text: input.text
    property string placeholderText: ""

    TextInput {
        id: input
        anchors.fill: parent
        anchors.margins: 10
        font.pixelSize: 20
        color: "black"
        placeholderText: root.placeholderText
    }
}
