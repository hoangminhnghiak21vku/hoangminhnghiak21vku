import QtQuick 2.15
import QtQuick.Controls 2.15

import "Common"

ApplicationWindow {
    visible: true
    width: 1280
    height: 720
    title: "Bluetooth Device Manager"

    // Property để lưu trạng thái Light/Dark Mode
    property bool statusBtn: true

    // Đường dẫn ảnh nền dựa vào chế độ
    property string bgImage: statusBtn ? "qrc:/Img/lightBg.png" : "qrc:/Img/darkBg.png"
    property string topBar: statusBtn ? "qrc:/Img/top_light.png" : "qrc:/Img/top_dark.png"
    property string iconBlt: statusBtn ? "qrc:/Img/iconBltBlack.png" : "qrc:/Img/iconBltWhite.png"

    Image {
        id: background
        anchors.fill: parent
        source: bgImage
    }

    Image {
        id: topBarImage
        width: parent.width
        height: 60
        source: topBar
    }

    QToggleButton {
        id: themeToggle
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 20
        onClicked: {
            statusBtn = !statusBtn
        }
    }

    Column {
        anchors.centerIn: parent
        spacing: 20

        Row {
            spacing: 10

            QTextBox {
                id: macInput
                width: 300
                height: 50
                placeholderText: "Enter MAC ID"
            }

            QTextBox {
                id: nameInput
                width: 300
                height: 50
                placeholderText: "Enter Device Name"
            }

            QButton {
                text: "ADD"
                onClicked: {
                    if (macInput.text !== "" && nameInput.text !== "") {
                        deviceModel.addDevice(macInput.text, nameInput.text)
                        macInput.text = ""
                        nameInput.text = ""
                    }
                }
            }
        }

        ListView {
            id: deviceList
            width: 800
            height: 400
            model: deviceModel
            delegate: QDelegateBox {
                textIndex: index + 1
                textMacID: model.macID
                textNameDevice: model.deviceName
            }
        }
    }
}
