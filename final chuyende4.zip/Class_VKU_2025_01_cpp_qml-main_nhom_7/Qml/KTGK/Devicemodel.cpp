#include "Devicemodel.h"

DeviceModel::DeviceModel(QObject *parent) : QAbstractListModel(parent) {}

int DeviceModel::rowCount(const QModelIndex &parent) const {
    Q_UNUSED(parent);
    return devices.count();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || index.row() >= devices.count())
        return QVariant();

    const Device &device = devices[index.row()];
    if (role == MacIdRole)
        return device.macId;
    else if (role == DeviceNameRole)
        return device.deviceName;

    return QVariant();
}

QHash<int, QByteArray> DeviceModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[MacIdRole] = "macId";
    roles[DeviceNameRole] = "deviceName";
    return roles;
}

void DeviceModel::addDevice(const QString &macId, const QString &deviceName) {
    beginInsertRows(QModelIndex(), devices.count(), devices.count());
    devices.append({macId, deviceName});
    endInsertRows();
}
