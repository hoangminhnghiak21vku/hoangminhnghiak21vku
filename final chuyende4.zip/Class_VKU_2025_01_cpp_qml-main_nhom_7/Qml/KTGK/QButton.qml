import QtQuick 2.15

Rectangle {
    id: root
    width: 80
    height: 50
    color: "orange"
    radius: 10

    signal clicked()

    Text {
        anchors.centerIn: parent
        text: "ADD"
        color: "white"
        font.pixelSize: 20
    }

    MouseArea {
        anchors.fill: parent
        onClicked: root.clicked()
    }
}
