#ifndef CALCULATORBACKEND_H
#define CALCULATORBACKEND_H

#include <QObject>

class CalculatorBackend : public QObject {
    Q_OBJECT
public:
    explicit CalculatorBackend(QObject *parent = nullptr);

    Q_INVOKABLE double calculate(double a, double b, const QString &op);
};

#endif // CALCULATORBACKEND_H
