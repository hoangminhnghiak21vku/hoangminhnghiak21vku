#include "calculatorbackend.h"

CalculatorBackend::CalculatorBackend(QObject *parent) : QObject(parent) {}

double CalculatorBackend::calculate(double a, double b, const QString &op) {
    if (op == "+") return a + b;
    if (op == "-") return a - b;
    if (op == "*") return a * b;
    if (op == "/") return (b != 0) ? a / b : 0;
    return 0;
}
