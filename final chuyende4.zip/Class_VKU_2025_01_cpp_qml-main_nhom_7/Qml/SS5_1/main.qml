import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 2.15

ApplicationWindow {
    visible: true
    width: 300
    height: 400
    title: "Máy tính Qt"

    Column {
        anchors.centerIn: parent
        spacing: 10

        Label {
            id: display
            text: "0"
            font.pixelSize: 24
            horizontalAlignment: Text.AlignRight
            width: parent.width
            height: 50
            background: Rectangle {
                color: "#ddd"
                radius: 5
            }
        }

        GridLayout {
            columns: 4
            rowSpacing: 5
            columnSpacing: 5
            anchors.horizontalCenter: parent.horizontalCenter

            Repeater {
                model: ["7", "8", "9", "+",
                        "4", "5", "6", "-",
                        "1", "2", "3", "*",
                        "C", "0", "=", "/"]

                Button {
                    text: modelData
                    width: 60
                    height: 50
                    onClicked: handleButtonPress(text)
                }
            }
        }
    }

    property string currentInput: "0"
    property string operator: ""
    property double firstNumber: 0
    property bool operatorPressed: false

    function handleButtonPress(value) {
        if (value >= "0" && value <= "9") {
            if (operatorPressed) {
                currentInput = value
                operatorPressed = false
            } else {
                currentInput = (currentInput === "0") ? value : currentInput + value
            }
            display.text = currentInput
        } else if (value === "C") {
            currentInput = "0"
            firstNumber = 0
            operator = ""
            operatorPressed = false
            display.text = "0"
        } else if (value === "=") {
            if (operator !== "" && currentInput !== "") {
                let secondNumber = parseFloat(currentInput)
                let result = calculatorbackend.calculate(firstNumber, secondNumber, operator)
                display.text = result.toString()
                currentInput = result.toString()
                operator = ""
                operatorPressed = false
            }
        } else { // Xử lý toán tử
            if (currentInput !== "") {
                firstNumber = parseFloat(currentInput)
                operator = value
                operatorPressed = true
                display.text = firstNumber + " " + operator
            }
        }
    }
}
