#include "Admin.h"
#include "Vehicle.h"
#include "ParkingTicket.h"
#include <iostream>
#include <limits>

using namespace std;

int main() {
    Admin admin;
    admin.inputInfo();

    int numOfficers;
    cout << "Enter number of ticket officers: ";
    while (!(cin >> numOfficers) || numOfficers <= 0) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input! Enter a positive number: ";
    }
    cin.ignore(); // Xóa bộ đệm ngay sau khi nhập số

    for (int i = 0; i < numOfficers; i++) {
        TicketOfficer officer;
        cout << "Enter ticket officer name: ";
        string name;
        getline(cin, name);
        officer.setName(name);
        admin.addOfficer(officer);
    }

    while (true) {
        cout << "\n1. Issue Ticket\n2. Print Summary\n3. View Ticket Officers' Shifts\n4. Change Shift\n5. Exit\nChoose an option: ";
        int choice;
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input! Please enter a number." << endl;
            continue;
        }
        cin.ignore(); // Xóa ký tự xuống dòng khỏi bộ đệm

        switch (choice) {
            case 1: {
                TicketOfficer* officer = admin.getActiveOfficer();
                if (!officer) {
                    cout << "No active ticket officer! Assign an officer first." << endl;
                    continue;
                }

                string customerName;
                cout << "Enter customer name: ";
                getline(cin, customerName);

                string vehicleType;
                cout << "Enter vehicle type (Motorbike/Car): ";
                getline(cin, vehicleType);

                Vehicle* vehicle = nullptr;
                if (vehicleType == "Motorbike") {
                    vehicle = new Motorbike();
                    admin.incrementTicketCount("Motorbike");
                } else if (vehicleType == "Car") {
                    vehicle = new Car();
                    admin.incrementTicketCount("Car");
                } else {
                    cout << "Invalid vehicle type!" << endl;
                    continue;
                }

                vehicle->inputVehicleInfo();
                vehicle->setExitTime();

                int hoursParked = vehicle->calculateHours();
                double fee = vehicle->calculateFee(hoursParked);

                cout << "Customer: " << customerName
                     << " | Vehicle: " << vehicle->getType()
                     << " | Hours: " << hoursParked
                     << " | Fee: " << fee << " VND" << endl;

                admin.updateRevenue(fee);

                delete vehicle;
                break;
            }
            case 2:
                admin.printSummary();
                break;
            case 3:
                admin.showOfficersShifts();
                break;
            case 4:
                admin.changeOfficerShift();
                break;
            case 5:
                cout << "Exiting..." << endl;
                return 0;
            default:
                cout << "Invalid choice! Try again." << endl;
                break;
        }
    }
}
