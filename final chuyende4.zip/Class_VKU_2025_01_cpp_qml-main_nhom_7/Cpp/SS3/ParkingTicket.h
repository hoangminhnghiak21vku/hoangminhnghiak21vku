#ifndef PARKINGTICKET_H
#define PARKINGTICKET_H

#include "Vehicle.h"
#include <iostream>
#include <ctime>

class ParkingTicket {
private:
    Vehicle* vehicle;
    int hours;
    double fee;
    string officerName;
    string customerName;
    time_t entryTime;
    time_t exitTime;

public:
    ParkingTicket(Vehicle* v, string officer, string customer, time_t entry)
        : vehicle(v), officerName(officer), customerName(customer), entryTime(entry), hours(0), fee(0) {}

    void exitParking(time_t exit) {
        exitTime = exit;
        hours = (exitTime - entryTime) / 3600;
        if (hours < 0) hours = 0;
        fee = vehicle->calculateFee(hours);
    }

    void printTicket() {
        cout << "Customer: " << customerName << " | Vehicle: " << vehicle->getType() 
             << " | Hours: " << hours << " | Fee: " << fee << " VND" << endl;
        cout << "Checked by: " << officerName << endl;
    }

    double getFee() { return fee; }
};

#endif
