#ifndef ADMIN_H
#define ADMIN_H

#include "Person.h"
#include "TicketOfficer.h"
#include <vector>
#include <limits>

#include <string>
#include <iostream>

class Admin : public Person {
private:
    std::vector<TicketOfficer> officers;
    int totalTickets;
    double totalRevenue;
    int motorbikeCount;
    int carCount;

public:
    Admin() : totalTickets(0), totalRevenue(0), motorbikeCount(0), carCount(0) {}

    void inputInfo() override {
        std::cout << "Enter admin name: ";
        std::string name;
        std::getline(std::cin, name);
        setName(name);
    }

    void addOfficer(const TicketOfficer& officer) {
        officers.push_back(officer);
        if (officers.size() == 1) {
            officers[0].setActive(true); // Mặc định kích hoạt người đầu tiên
        }
    }

    TicketOfficer* getActiveOfficer() {
        for (auto& officer : officers) {
            if (officer.isActive()) {
                return &officer;
            }
        }
        return nullptr;
    }

    std::string getActiveOfficerName() const {
        for (const auto& officer : officers) {
            if (officer.isActive()) {
                return officer.getName();
            }
        }
        return "None";
    }

    void updateRevenue(double amount) {
        totalRevenue += amount;
    }

    void incrementTicketCount(const std::string& vehicleType) {
        totalTickets++;
        if (vehicleType == "Motorbike") {
            motorbikeCount++;
        } else if (vehicleType == "Car") {
            carCount++;
        }
    }

    int getTotalTickets() const {
        return totalTickets;
    }

    double getTotalRevenue() const {
        return totalRevenue;
    }

    int getMotorbikeCount() const {
        return motorbikeCount;
    }

    int getCarCount() const {
        return carCount;
    }

    void printSummary() const {
        std::cout << "\n===== Summary =====" << std::endl;
        std::cout << "Total tickets sold: " << totalTickets 
                  << " | Total revenue: " << totalRevenue << " VND" << std::endl;
        std::cout << "Motorbikes: " << motorbikeCount << " | Cars: " << carCount << std::endl;
        std::cout << "Current active officer: " << getActiveOfficerName() << std::endl;
    }

    void showOfficersShifts() const {
        std::cout << "\n===== Ticket Officers' Shifts =====" << std::endl;
        for (size_t i = 0; i < officers.size(); i++) {
            std::cout << i + 1 << ". " << officers[i].getName() 
                      << (officers[i].isActive() ? " (Active)" : "") << std::endl;
        }
    }

    void changeOfficerShift() {
        if (officers.empty()) {
            std::cout << "No officers available to change shift." << std::endl;
            return;
        }
        
        std::cout << "Current officers:" << std::endl;
        for (size_t i = 0; i < officers.size(); i++) {
            std::cout << i + 1 << ". " << officers[i].getName() 
                      << (officers[i].isActive() ? " (Active)" : "") << std::endl;
        }
        
        int choice;
        std::cout << "Enter officer number to activate: ";
        while (!(std::cin >> choice) || choice < 1 || choice > (int)officers.size()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid choice. Try again: ";
        }

        for (auto& officer : officers) {
            officer.setActive(false);
        }
        officers[choice - 1].setActive(true);
        std::cout << "Shift changed. New active officer: " << officers[choice - 1].getName() << std::endl;
    }
};

#endif // ADMIN_H
