#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>
#include <limits>

using namespace std;

class Vehicle {
protected:
    string type;
    double baseRate;
    int entryTime;
    int exitTime;

public:
    Vehicle() : entryTime(0), exitTime(0) {}
    virtual ~Vehicle() {}

    virtual double calculateFee(int hours) = 0;
    
    void inputVehicleInfo() {
        cout << "Enter entry time (hour): ";
        while (!(cin >> entryTime) || entryTime <= 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input! Enter a positive number: ";
        }
    }

    void setExitTime() {
        cout << "Enter exit time (hour): ";
        while (!(cin >> exitTime) || exitTime <= entryTime) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input! Exit time must be greater than entry time: ";
        }
    }

    int calculateHours() const {
        return exitTime - entryTime;
    }

    string getType() const { return type; }
};

class Motorbike : public Vehicle {
public:
    Motorbike() { baseRate = 5000; type = "Motorbike"; }

    double calculateFee(int hours) override {
        if (hours <= 5) return baseRate;
        if (hours <= 10) return baseRate * 2;
        if (hours <= 24) return baseRate * 4;
        return baseRate * 8;
    }
};

class Car : public Vehicle {
public:
    Car() { baseRate = 10000; type = "Car"; }

    double calculateFee(int hours) override {
        if (hours <= 5) return baseRate;
        if (hours <= 10) return baseRate * 2;
        if (hours <= 24) return baseRate * 4;
        return baseRate * 8;
    }
};

#endif
