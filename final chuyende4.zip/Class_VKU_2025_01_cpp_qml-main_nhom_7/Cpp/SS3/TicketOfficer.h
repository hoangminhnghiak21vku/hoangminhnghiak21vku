#ifndef TICKETOFFICER_H
#define TICKETOFFICER_H

#include "Person.h"
#include "ParkingTicket.h"
#include <ctime>

class TicketOfficer : public Person {
    private:
    bool active;
public:
    TicketOfficer() { role = "Ticket Officer"; }

    void inputInfo() override {
        cout << "Enter ticket officer name: ";
        cin.ignore();
        getline(cin, name);
    }

    ParkingTicket* issueTicket(Vehicle* v, string customer) {
        return new ParkingTicket(v, name, customer, time(0));
    }
    public:
    void setName(const string& newName) {
        name = newName;
    }
    string getName() const {
        return name;
    }
        void setActive(bool status) {
        active = status;
    }

    bool isActive() const {
        return active;
    }
};

#endif
