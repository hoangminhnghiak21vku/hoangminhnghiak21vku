#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    string role;

public:
    Person() {}
    
    virtual void inputInfo() {
        cout << "Enter name: ";
        cin.ignore();
        getline(cin, name);
    }

    virtual void displayInfo() {
        cout << "Name: " << name << " | Role: " << role << endl;
    }

    void setName(const std::string& newName) {
        name = newName;
    }

    std::string getName() const {
        return name;
    }
};

#endif
