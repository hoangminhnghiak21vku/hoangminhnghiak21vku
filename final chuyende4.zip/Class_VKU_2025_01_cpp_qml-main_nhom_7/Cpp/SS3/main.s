	.file	"main.cpp"
	.text
	.section	.text._ZnwmPv,"axG",@progbits,_ZnwmPv,comdat
	.weak	_ZnwmPv
	.type	_ZnwmPv, @function
_ZnwmPv:
.LFB38:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE38:
	.size	_ZnwmPv, .-_ZnwmPv
	.section	.text._ZdlPvS_,"axG",@progbits,_ZdlPvS_,comdat
	.weak	_ZdlPvS_
	.type	_ZdlPvS_, @function
_ZdlPvS_:
.LFB40:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE40:
	.size	_ZdlPvS_, .-_ZdlPvS_
	.section	.text._ZNSt11char_traitsIcE6lengthEPKc,"axG",@progbits,_ZNSt11char_traitsIcE6lengthEPKc,comdat
	.weak	_ZNSt11char_traitsIcE6lengthEPKc
	.type	_ZNSt11char_traitsIcE6lengthEPKc, @function
_ZNSt11char_traitsIcE6lengthEPKc:
.LFB450:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, -8(%rbp)
	movl	$0, %eax
	testb	%al, %al
	je	.L6
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc
	jmp	.L7
.L6:
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	strlen@PLT
	nop
.L7:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE450:
	.size	_ZNSt11char_traitsIcE6lengthEPKc, .-_ZNSt11char_traitsIcE6lengthEPKc
	.local	_ZStL8__ioinit
	.comm	_ZStL8__ioinit,1,1
	.section	.text._ZN6PersonC2Ev,"axG",@progbits,_ZN6PersonC5Ev,comdat
	.align 2
	.weak	_ZN6PersonC2Ev
	.type	_ZN6PersonC2Ev, @function
_ZN6PersonC2Ev:
.LFB1733:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV6Person(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	movq	-8(%rbp), %rax
	addq	$40, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1733:
	.size	_ZN6PersonC2Ev, .-_ZN6PersonC2Ev
	.weak	_ZN6PersonC1Ev
	.set	_ZN6PersonC1Ev,_ZN6PersonC2Ev
	.section	.rodata
.LC0:
	.string	"Enter name: "
	.section	.text._ZN6Person9inputInfoEv,"axG",@progbits,_ZN6Person9inputInfoEv,comdat
	.align 2
	.weak	_ZN6Person9inputInfoEv
	.type	_ZN6Person9inputInfoEv, @function
_ZN6Person9inputInfoEv:
.LFB1735:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEv@PLT
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1735:
	.size	_ZN6Person9inputInfoEv, .-_ZN6Person9inputInfoEv
	.section	.rodata
.LC1:
	.string	"Name: "
.LC2:
	.string	" | Role: "
	.section	.text._ZN6Person11displayInfoEv,"axG",@progbits,_ZN6Person11displayInfoEv,comdat
	.align 2
	.weak	_ZN6Person11displayInfoEv
	.type	_ZN6Person11displayInfoEv, @function
_ZN6Person11displayInfoEv:
.LFB1736:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	%rax, %rdx
	leaq	.LC2(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-8(%rbp), %rax
	addq	$40, %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1736:
	.size	_ZN6Person11displayInfoEv, .-_ZN6Person11displayInfoEv
	.section	.text._ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.align 2
	.weak	_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, @function
_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE:
.LFB1737:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-16(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSERKS4_@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1737:
	.size	_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .-_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.section	.text._ZNSt14numeric_limitsIlE3maxEv,"axG",@progbits,_ZNSt14numeric_limitsIlE3maxEv,comdat
	.weak	_ZNSt14numeric_limitsIlE3maxEv
	.type	_ZNSt14numeric_limitsIlE3maxEv, @function
_ZNSt14numeric_limitsIlE3maxEv:
.LFB1848:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movabsq	$9223372036854775807, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1848:
	.size	_ZNSt14numeric_limitsIlE3maxEv, .-_ZNSt14numeric_limitsIlE3maxEv
	.section	.text._ZN7VehicleC2Ev,"axG",@progbits,_ZN7VehicleC5Ev,comdat
	.align 2
	.weak	_ZN7VehicleC2Ev
	.type	_ZN7VehicleC2Ev, @function
_ZN7VehicleC2Ev:
.LFB1929:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV7Vehicle(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	movq	-8(%rbp), %rax
	movl	$0, 48(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 52(%rax)
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1929:
	.size	_ZN7VehicleC2Ev, .-_ZN7VehicleC2Ev
	.weak	_ZN7VehicleC1Ev
	.set	_ZN7VehicleC1Ev,_ZN7VehicleC2Ev
	.section	.text._ZN7VehicleD2Ev,"axG",@progbits,_ZN7VehicleD5Ev,comdat
	.align 2
	.weak	_ZN7VehicleD2Ev
	.type	_ZN7VehicleD2Ev, @function
_ZN7VehicleD2Ev:
.LFB1932:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV7Vehicle(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1932:
	.size	_ZN7VehicleD2Ev, .-_ZN7VehicleD2Ev
	.weak	_ZN7VehicleD1Ev
	.set	_ZN7VehicleD1Ev,_ZN7VehicleD2Ev
	.section	.text._ZN7VehicleD0Ev,"axG",@progbits,_ZN7VehicleD5Ev,comdat
	.align 2
	.weak	_ZN7VehicleD0Ev
	.type	_ZN7VehicleD0Ev, @function
_ZN7VehicleD0Ev:
.LFB1934:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleD1Ev
	movq	-8(%rbp), %rax
	movl	$56, %esi
	movq	%rax, %rdi
	call	_ZdlPvm@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1934:
	.size	_ZN7VehicleD0Ev, .-_ZN7VehicleD0Ev
	.section	.rodata
.LC3:
	.string	"Enter entry time (hour): "
	.align 8
.LC4:
	.string	"Invalid input! Enter a positive number: "
	.section	.text._ZN7Vehicle16inputVehicleInfoEv,"axG",@progbits,_ZN7Vehicle16inputVehicleInfoEv,comdat
	.align 2
	.weak	_ZN7Vehicle16inputVehicleInfoEv
	.type	_ZN7Vehicle16inputVehicleInfoEv, @function
_ZN7Vehicle16inputVehicleInfoEv:
.LFB1935:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	jmp	.L18
.L22:
	movl	$0, %esi
	leaq	16+_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@PLT
	call	_ZNSt14numeric_limitsIlE3maxEv
	movl	$10, %edx
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEli@PLT
	leaq	.LC4(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.L18:
	movq	-8(%rbp), %rax
	addq	$48, %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	subq	$24, %rdx
	movq	(%rdx), %rdx
	addq	%rdx, %rax
	movq	%rax, %rdi
	call	_ZNKSt9basic_iosIcSt11char_traitsIcEEntEv@PLT
	testb	%al, %al
	jne	.L19
	movq	-8(%rbp), %rax
	movl	48(%rax), %eax
	testl	%eax, %eax
	jg	.L20
.L19:
	movl	$1, %eax
	jmp	.L21
.L20:
	movl	$0, %eax
.L21:
	testb	%al, %al
	jne	.L22
	nop
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1935:
	.size	_ZN7Vehicle16inputVehicleInfoEv, .-_ZN7Vehicle16inputVehicleInfoEv
	.section	.rodata
.LC5:
	.string	"Enter exit time (hour): "
	.align 8
.LC6:
	.string	"Invalid input! Exit time must be greater than entry time: "
	.section	.text._ZN7Vehicle11setExitTimeEv,"axG",@progbits,_ZN7Vehicle11setExitTimeEv,comdat
	.align 2
	.weak	_ZN7Vehicle11setExitTimeEv
	.type	_ZN7Vehicle11setExitTimeEv, @function
_ZN7Vehicle11setExitTimeEv:
.LFB1936:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	jmp	.L24
.L28:
	movl	$0, %esi
	leaq	16+_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@PLT
	call	_ZNSt14numeric_limitsIlE3maxEv
	movl	$10, %edx
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEli@PLT
	leaq	.LC6(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.L24:
	movq	-8(%rbp), %rax
	addq	$52, %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	subq	$24, %rdx
	movq	(%rdx), %rdx
	addq	%rdx, %rax
	movq	%rax, %rdi
	call	_ZNKSt9basic_iosIcSt11char_traitsIcEEntEv@PLT
	testb	%al, %al
	jne	.L25
	movq	-8(%rbp), %rax
	movl	52(%rax), %edx
	movq	-8(%rbp), %rax
	movl	48(%rax), %eax
	cmpl	%eax, %edx
	jg	.L26
.L25:
	movl	$1, %eax
	jmp	.L27
.L26:
	movl	$0, %eax
.L27:
	testb	%al, %al
	jne	.L28
	nop
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1936:
	.size	_ZN7Vehicle11setExitTimeEv, .-_ZN7Vehicle11setExitTimeEv
	.section	.text._ZNK7Vehicle14calculateHoursEv,"axG",@progbits,_ZNK7Vehicle14calculateHoursEv,comdat
	.align 2
	.weak	_ZNK7Vehicle14calculateHoursEv
	.type	_ZNK7Vehicle14calculateHoursEv, @function
_ZNK7Vehicle14calculateHoursEv:
.LFB1937:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	52(%rax), %edx
	movq	-8(%rbp), %rax
	movl	48(%rax), %ecx
	movl	%edx, %eax
	subl	%ecx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1937:
	.size	_ZNK7Vehicle14calculateHoursEv, .-_ZNK7Vehicle14calculateHoursEv
	.section	.text._ZNK7Vehicle7getTypeB5cxx11Ev,"axG",@progbits,_ZNK7Vehicle7getTypeB5cxx11Ev,comdat
	.align 2
	.weak	_ZNK7Vehicle7getTypeB5cxx11Ev
	.type	_ZNK7Vehicle7getTypeB5cxx11Ev, @function
_ZNK7Vehicle7getTypeB5cxx11Ev:
.LFB1938:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1ERKS4_@PLT
	movq	-8(%rbp), %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1938:
	.size	_ZNK7Vehicle7getTypeB5cxx11Ev, .-_ZNK7Vehicle7getTypeB5cxx11Ev
	.section	.rodata
.LC8:
	.string	"Motorbike"
	.section	.text._ZN9MotorbikeC2Ev,"axG",@progbits,_ZN9MotorbikeC5Ev,comdat
	.align 2
	.weak	_ZN9MotorbikeC2Ev
	.type	_ZN9MotorbikeC2Ev, @function
_ZN9MotorbikeC2Ev:
.LFB1940:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA1940
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleC2Ev
	leaq	16+_ZTV9Motorbike(%rip), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-24(%rbp), %rax
	movsd	.LC7(%rip), %xmm0
	movsd	%xmm0, 40(%rax)
	movq	-24(%rbp), %rax
	addq	$8, %rax
	leaq	.LC8(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB0:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEPKc@PLT
.LEHE0:
	jmp	.L36
.L35:
	endbr64
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleD2Ev
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB1:
	call	_Unwind_Resume@PLT
.LEHE1:
.L36:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1940:
	.globl	__gxx_personality_v0
	.section	.gcc_except_table._ZN9MotorbikeC2Ev,"aG",@progbits,_ZN9MotorbikeC5Ev,comdat
.LLSDA1940:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1940-.LLSDACSB1940
.LLSDACSB1940:
	.uleb128 .LEHB0-.LFB1940
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L35-.LFB1940
	.uleb128 0
	.uleb128 .LEHB1-.LFB1940
	.uleb128 .LEHE1-.LEHB1
	.uleb128 0
	.uleb128 0
.LLSDACSE1940:
	.section	.text._ZN9MotorbikeC2Ev,"axG",@progbits,_ZN9MotorbikeC5Ev,comdat
	.size	_ZN9MotorbikeC2Ev, .-_ZN9MotorbikeC2Ev
	.weak	_ZN9MotorbikeC1Ev
	.set	_ZN9MotorbikeC1Ev,_ZN9MotorbikeC2Ev
	.section	.text._ZN9Motorbike12calculateFeeEi,"axG",@progbits,_ZN9Motorbike12calculateFeeEi,comdat
	.align 2
	.weak	_ZN9Motorbike12calculateFeeEi
	.type	_ZN9Motorbike12calculateFeeEi, @function
_ZN9Motorbike12calculateFeeEi:
.LFB1942:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	cmpl	$5, -12(%rbp)
	jg	.L38
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm0
	jmp	.L39
.L38:
	cmpl	$10, -12(%rbp)
	jg	.L40
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm0
	addsd	%xmm0, %xmm0
	jmp	.L39
.L40:
	cmpl	$24, -12(%rbp)
	jg	.L41
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm1
	movsd	.LC9(%rip), %xmm0
	mulsd	%xmm1, %xmm0
	jmp	.L39
.L41:
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm1
	movsd	.LC10(%rip), %xmm0
	mulsd	%xmm1, %xmm0
.L39:
	movq	%xmm0, %rax
	movq	%rax, %xmm0
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1942:
	.size	_ZN9Motorbike12calculateFeeEi, .-_ZN9Motorbike12calculateFeeEi
	.section	.rodata
.LC12:
	.string	"Car"
	.section	.text._ZN3CarC2Ev,"axG",@progbits,_ZN3CarC5Ev,comdat
	.align 2
	.weak	_ZN3CarC2Ev
	.type	_ZN3CarC2Ev, @function
_ZN3CarC2Ev:
.LFB1944:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA1944
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleC2Ev
	leaq	16+_ZTV3Car(%rip), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-24(%rbp), %rax
	movsd	.LC11(%rip), %xmm0
	movsd	%xmm0, 40(%rax)
	movq	-24(%rbp), %rax
	addq	$8, %rax
	leaq	.LC12(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB2:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEPKc@PLT
.LEHE2:
	jmp	.L45
.L44:
	endbr64
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleD2Ev
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.LEHE3:
.L45:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1944:
	.section	.gcc_except_table._ZN3CarC2Ev,"aG",@progbits,_ZN3CarC5Ev,comdat
.LLSDA1944:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1944-.LLSDACSB1944
.LLSDACSB1944:
	.uleb128 .LEHB2-.LFB1944
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L44-.LFB1944
	.uleb128 0
	.uleb128 .LEHB3-.LFB1944
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE1944:
	.section	.text._ZN3CarC2Ev,"axG",@progbits,_ZN3CarC5Ev,comdat
	.size	_ZN3CarC2Ev, .-_ZN3CarC2Ev
	.weak	_ZN3CarC1Ev
	.set	_ZN3CarC1Ev,_ZN3CarC2Ev
	.section	.text._ZN3Car12calculateFeeEi,"axG",@progbits,_ZN3Car12calculateFeeEi,comdat
	.align 2
	.weak	_ZN3Car12calculateFeeEi
	.type	_ZN3Car12calculateFeeEi, @function
_ZN3Car12calculateFeeEi:
.LFB1946:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	cmpl	$5, -12(%rbp)
	jg	.L47
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm0
	jmp	.L48
.L47:
	cmpl	$10, -12(%rbp)
	jg	.L49
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm0
	addsd	%xmm0, %xmm0
	jmp	.L48
.L49:
	cmpl	$24, -12(%rbp)
	jg	.L50
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm1
	movsd	.LC9(%rip), %xmm0
	mulsd	%xmm1, %xmm0
	jmp	.L48
.L50:
	movq	-8(%rbp), %rax
	movsd	40(%rax), %xmm1
	movsd	.LC10(%rip), %xmm0
	mulsd	%xmm1, %xmm0
.L48:
	movq	%xmm0, %rax
	movq	%rax, %xmm0
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1946:
	.size	_ZN3Car12calculateFeeEi, .-_ZN3Car12calculateFeeEi
	.section	.text._ZN6PersonD2Ev,"axG",@progbits,_ZN6PersonD5Ev,comdat
	.align 2
	.weak	_ZN6PersonD2Ev
	.type	_ZN6PersonD2Ev, @function
_ZN6PersonD2Ev:
.LFB1955:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV6Person(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$40, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1955:
	.size	_ZN6PersonD2Ev, .-_ZN6PersonD2Ev
	.weak	_ZN6PersonD1Ev
	.set	_ZN6PersonD1Ev,_ZN6PersonD2Ev
	.section	.rodata
.LC13:
	.string	"Ticket Officer"
	.section	.text._ZN13TicketOfficerC2Ev,"axG",@progbits,_ZN13TicketOfficerC5Ev,comdat
	.align 2
	.weak	_ZN13TicketOfficerC2Ev
	.type	_ZN13TicketOfficerC2Ev, @function
_ZN13TicketOfficerC2Ev:
.LFB1957:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA1957
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN6PersonC2Ev
	leaq	16+_ZTV13TicketOfficer(%rip), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-24(%rbp), %rax
	addq	$40, %rax
	leaq	.LC13(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB4:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEPKc@PLT
.LEHE4:
	jmp	.L55
.L54:
	endbr64
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN6PersonD2Ev
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB5:
	call	_Unwind_Resume@PLT
.LEHE5:
.L55:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1957:
	.section	.gcc_except_table._ZN13TicketOfficerC2Ev,"aG",@progbits,_ZN13TicketOfficerC5Ev,comdat
.LLSDA1957:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1957-.LLSDACSB1957
.LLSDACSB1957:
	.uleb128 .LEHB4-.LFB1957
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L54-.LFB1957
	.uleb128 0
	.uleb128 .LEHB5-.LFB1957
	.uleb128 .LEHE5-.LEHB5
	.uleb128 0
	.uleb128 0
.LLSDACSE1957:
	.section	.text._ZN13TicketOfficerC2Ev,"axG",@progbits,_ZN13TicketOfficerC5Ev,comdat
	.size	_ZN13TicketOfficerC2Ev, .-_ZN13TicketOfficerC2Ev
	.weak	_ZN13TicketOfficerC1Ev
	.set	_ZN13TicketOfficerC1Ev,_ZN13TicketOfficerC2Ev
	.section	.rodata
.LC14:
	.string	"Enter ticket officer name: "
	.section	.text._ZN13TicketOfficer9inputInfoEv,"axG",@progbits,_ZN13TicketOfficer9inputInfoEv,comdat
	.align 2
	.weak	_ZN13TicketOfficer9inputInfoEv
	.type	_ZN13TicketOfficer9inputInfoEv, @function
_ZN13TicketOfficer9inputInfoEv:
.LFB1959:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEv@PLT
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1959:
	.size	_ZN13TicketOfficer9inputInfoEv, .-_ZN13TicketOfficer9inputInfoEv
	.section	.text._ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.align 2
	.weak	_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, @function
_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE:
.LFB1961:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-16(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSERKS4_@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1961:
	.size	_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .-_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.section	.text._ZNK13TicketOfficer7getNameB5cxx11Ev,"axG",@progbits,_ZNK13TicketOfficer7getNameB5cxx11Ev,comdat
	.align 2
	.weak	_ZNK13TicketOfficer7getNameB5cxx11Ev
	.type	_ZNK13TicketOfficer7getNameB5cxx11Ev, @function
_ZNK13TicketOfficer7getNameB5cxx11Ev:
.LFB1962:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1ERKS4_@PLT
	movq	-8(%rbp), %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1962:
	.size	_ZNK13TicketOfficer7getNameB5cxx11Ev, .-_ZNK13TicketOfficer7getNameB5cxx11Ev
	.section	.text._ZN13TicketOfficer9setActiveEb,"axG",@progbits,_ZN13TicketOfficer9setActiveEb,comdat
	.align 2
	.weak	_ZN13TicketOfficer9setActiveEb
	.type	_ZN13TicketOfficer9setActiveEb, @function
_ZN13TicketOfficer9setActiveEb:
.LFB1963:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, %eax
	movb	%al, -12(%rbp)
	movq	-8(%rbp), %rax
	movzbl	-12(%rbp), %edx
	movb	%dl, 72(%rax)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1963:
	.size	_ZN13TicketOfficer9setActiveEb, .-_ZN13TicketOfficer9setActiveEb
	.section	.text._ZNK13TicketOfficer8isActiveEv,"axG",@progbits,_ZNK13TicketOfficer8isActiveEv,comdat
	.align 2
	.weak	_ZNK13TicketOfficer8isActiveEv
	.type	_ZNK13TicketOfficer8isActiveEv, @function
_ZNK13TicketOfficer8isActiveEv:
.LFB1964:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movzbl	72(%rax), %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1964:
	.size	_ZNK13TicketOfficer8isActiveEv, .-_ZNK13TicketOfficer8isActiveEv
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD5Ev,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev:
.LFB2325:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaI13TicketOfficerED2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2325:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD1Ev
	.set	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD1Ev,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD2Ev
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC5Ev,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev:
.LFB2327:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC1Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2327:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC1Ev
	.set	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC1Ev,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EEC5Ev,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev:
.LFB2329:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EEC2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2329:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev, .-_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EEC1Ev
	.set	_ZNSt6vectorI13TicketOfficerSaIS0_EEC1Ev,_ZNSt6vectorI13TicketOfficerSaIS0_EEC2Ev
	.section	.text._ZN5AdminC2Ev,"axG",@progbits,_ZN5AdminC5Ev,comdat
	.align 2
	.weak	_ZN5AdminC2Ev
	.type	_ZN5AdminC2Ev, @function
_ZN5AdminC2Ev:
.LFB2331:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN6PersonC2Ev
	leaq	16+_ZTV5Admin(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEC1Ev
	movq	-8(%rbp), %rax
	movl	$0, 96(%rax)
	movq	-8(%rbp), %rax
	pxor	%xmm0, %xmm0
	movsd	%xmm0, 104(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 112(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 116(%rax)
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2331:
	.size	_ZN5AdminC2Ev, .-_ZN5AdminC2Ev
	.weak	_ZN5AdminC1Ev
	.set	_ZN5AdminC1Ev,_ZN5AdminC2Ev
	.section	.rodata
.LC16:
	.string	"Enter admin name: "
	.section	.text._ZN5Admin9inputInfoEv,"axG",@progbits,_ZN5Admin9inputInfoEv,comdat
	.align 2
	.weak	_ZN5Admin9inputInfoEv
	.type	_ZN5Admin9inputInfoEv, @function
_ZN5Admin9inputInfoEv:
.LFB2333:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2333
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -72(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	leaq	.LC16(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB6:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.LEHE6:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	leaq	-64(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
.LEHB7:
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	-72(%rbp), %rax
	leaq	-64(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN6Person7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.LEHE7:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L69
	jmp	.L71
.L70:
	endbr64
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB8:
	call	_Unwind_Resume@PLT
.LEHE8:
.L71:
	call	__stack_chk_fail@PLT
.L69:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2333:
	.section	.gcc_except_table._ZN5Admin9inputInfoEv,"aG",@progbits,_ZN5Admin9inputInfoEv,comdat
.LLSDA2333:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2333-.LLSDACSB2333
.LLSDACSB2333:
	.uleb128 .LEHB6-.LFB2333
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB7-.LFB2333
	.uleb128 .LEHE7-.LEHB7
	.uleb128 .L70-.LFB2333
	.uleb128 0
	.uleb128 .LEHB8-.LFB2333
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
.LLSDACSE2333:
	.section	.text._ZN5Admin9inputInfoEv,"axG",@progbits,_ZN5Admin9inputInfoEv,comdat
	.size	_ZN5Admin9inputInfoEv, .-_ZN5Admin9inputInfoEv
	.section	.text._ZN5Admin10addOfficerERK13TicketOfficer,"axG",@progbits,_ZN5Admin10addOfficerERK13TicketOfficer,comdat
	.align 2
	.weak	_ZN5Admin10addOfficerERK13TicketOfficer
	.type	_ZN5Admin10addOfficerERK13TicketOfficer, @function
_ZN5Admin10addOfficerERK13TicketOfficer:
.LFB2334:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	leaq	72(%rax), %rdx
	movq	-16(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_
	movq	-8(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	cmpq	$1, %rax
	sete	%al
	testb	%al, %al
	je	.L74
	movq	-8(%rbp), %rax
	addq	$72, %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	movl	$1, %esi
	movq	%rax, %rdi
	call	_ZN13TicketOfficer9setActiveEb
.L74:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2334:
	.size	_ZN5Admin10addOfficerERK13TicketOfficer, .-_ZN5Admin10addOfficerERK13TicketOfficer
	.section	.text._ZN5Admin16getActiveOfficerEv,"axG",@progbits,_ZN5Admin16getActiveOfficerEv,comdat
	.align 2
	.weak	_ZN5Admin16getActiveOfficerEv
	.type	_ZN5Admin16getActiveOfficerEv, @function
_ZN5Admin16getActiveOfficerEv:
.LFB2335:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$64, %rsp
	movq	%rdi, -56(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-56(%rbp), %rax
	addq	$72, %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	movq	%rax, -40(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv
	movq	%rax, -32(%rbp)
	jmp	.L76
.L79:
	leaq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer8isActiveEv
	testb	%al, %al
	je	.L77
	movq	-16(%rbp), %rax
	jmp	.L78
.L77:
	leaq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
.L76:
	leaq	-32(%rbp), %rdx
	leaq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_
	testb	%al, %al
	jne	.L79
	movl	$0, %eax
.L78:
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L80
	call	__stack_chk_fail@PLT
.L80:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2335:
	.size	_ZN5Admin16getActiveOfficerEv, .-_ZN5Admin16getActiveOfficerEv
	.section	.rodata
.LC17:
	.string	"None"
	.section	.text._ZNK5Admin20getActiveOfficerNameB5cxx11Ev,"axG",@progbits,_ZNK5Admin20getActiveOfficerNameB5cxx11Ev,comdat
	.align 2
	.weak	_ZNK5Admin20getActiveOfficerNameB5cxx11Ev
	.type	_ZNK5Admin20getActiveOfficerNameB5cxx11Ev, @function
_ZNK5Admin20getActiveOfficerNameB5cxx11Ev:
.LFB2336:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2336
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -72(%rbp)
	movq	%rsi, -80(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-80(%rbp), %rax
	addq	$72, %rax
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	movq	%rax, -56(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv
	movq	%rax, -48(%rbp)
	jmp	.L82
.L85:
	leaq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer8isActiveEv
	testb	%al, %al
	je	.L83
	movq	-72(%rbp), %rax
	movq	-32(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB9:
	call	_ZNK13TicketOfficer7getNameB5cxx11Ev
.LEHE9:
	jmp	.L81
.L83:
	leaq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
.L82:
	leaq	-48(%rbp), %rdx
	leaq	-56(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	testb	%al, %al
	jne	.L85
	leaq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcEC1Ev@PLT
	leaq	-48(%rbp), %rdx
	movq	-72(%rbp), %rax
	leaq	.LC17(%rip), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB10:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_
.LEHE10:
	leaq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	jmp	.L81
.L88:
	endbr64
	movq	%rax, %rbx
	leaq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB11:
	call	_Unwind_Resume@PLT
.LEHE11:
.L81:
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L87
	call	__stack_chk_fail@PLT
.L87:
	movq	-72(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2336:
	.section	.gcc_except_table._ZNK5Admin20getActiveOfficerNameB5cxx11Ev,"aG",@progbits,_ZNK5Admin20getActiveOfficerNameB5cxx11Ev,comdat
.LLSDA2336:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2336-.LLSDACSB2336
.LLSDACSB2336:
	.uleb128 .LEHB9-.LFB2336
	.uleb128 .LEHE9-.LEHB9
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB10-.LFB2336
	.uleb128 .LEHE10-.LEHB10
	.uleb128 .L88-.LFB2336
	.uleb128 0
	.uleb128 .LEHB11-.LFB2336
	.uleb128 .LEHE11-.LEHB11
	.uleb128 0
	.uleb128 0
.LLSDACSE2336:
	.section	.text._ZNK5Admin20getActiveOfficerNameB5cxx11Ev,"axG",@progbits,_ZNK5Admin20getActiveOfficerNameB5cxx11Ev,comdat
	.size	_ZNK5Admin20getActiveOfficerNameB5cxx11Ev, .-_ZNK5Admin20getActiveOfficerNameB5cxx11Ev
	.section	.text._ZN5Admin13updateRevenueEd,"axG",@progbits,_ZN5Admin13updateRevenueEd,comdat
	.align 2
	.weak	_ZN5Admin13updateRevenueEd
	.type	_ZN5Admin13updateRevenueEd, @function
_ZN5Admin13updateRevenueEd:
.LFB2337:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movsd	%xmm0, -16(%rbp)
	movq	-8(%rbp), %rax
	movsd	104(%rax), %xmm0
	addsd	-16(%rbp), %xmm0
	movq	-8(%rbp), %rax
	movsd	%xmm0, 104(%rax)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2337:
	.size	_ZN5Admin13updateRevenueEd, .-_ZN5Admin13updateRevenueEd
	.section	.text._ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,"axG",@progbits,_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,comdat
	.align 2
	.weak	_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, @function
_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE:
.LFB2338:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movl	96(%rax), %eax
	leal	1(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 96(%rax)
	movq	-16(%rbp), %rax
	leaq	.LC8(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	testb	%al, %al
	je	.L91
	movq	-8(%rbp), %rax
	movl	112(%rax), %eax
	leal	1(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 112(%rax)
	jmp	.L93
.L91:
	movq	-16(%rbp), %rax
	leaq	.LC12(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	testb	%al, %al
	je	.L93
	movq	-8(%rbp), %rax
	movl	116(%rax), %eax
	leal	1(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 116(%rax)
.L93:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2338:
	.size	_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .-_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.section	.rodata
.LC18:
	.string	"\n===== Summary ====="
.LC19:
	.string	"Total tickets sold: "
.LC20:
	.string	" | Total revenue: "
.LC21:
	.string	" VND"
.LC22:
	.string	"Motorbikes: "
.LC23:
	.string	" | Cars: "
.LC24:
	.string	"Current active officer: "
	.section	.text._ZNK5Admin12printSummaryEv,"axG",@progbits,_ZNK5Admin12printSummaryEv,comdat
	.align 2
	.weak	_ZNK5Admin12printSummaryEv
	.type	_ZNK5Admin12printSummaryEv, @function
_ZNK5Admin12printSummaryEv:
.LFB2343:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2343
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -72(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	leaq	.LC18(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB12:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	leaq	.LC19(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-72(%rbp), %rax
	movl	96(%rax), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdx
	leaq	.LC20(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-72(%rbp), %rax
	movq	104(%rax), %rax
	movq	%rax, %xmm0
	movq	%rdx, %rdi
	call	_ZNSolsEd@PLT
	movq	%rax, %rdx
	leaq	.LC21(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	leaq	.LC22(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-72(%rbp), %rax
	movl	112(%rax), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdx
	leaq	.LC23(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-72(%rbp), %rax
	movl	116(%rax), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	_ZNSolsEi@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	leaq	.LC24(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNK5Admin20getActiveOfficerNameB5cxx11Ev
.LEHE12:
	leaq	-64(%rbp), %rax
	movq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB13:
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE13:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	nop
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L96
	jmp	.L98
.L97:
	endbr64
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB14:
	call	_Unwind_Resume@PLT
.LEHE14:
.L98:
	call	__stack_chk_fail@PLT
.L96:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2343:
	.section	.gcc_except_table._ZNK5Admin12printSummaryEv,"aG",@progbits,_ZNK5Admin12printSummaryEv,comdat
.LLSDA2343:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2343-.LLSDACSB2343
.LLSDACSB2343:
	.uleb128 .LEHB12-.LFB2343
	.uleb128 .LEHE12-.LEHB12
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB13-.LFB2343
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L97-.LFB2343
	.uleb128 0
	.uleb128 .LEHB14-.LFB2343
	.uleb128 .LEHE14-.LEHB14
	.uleb128 0
	.uleb128 0
.LLSDACSE2343:
	.section	.text._ZNK5Admin12printSummaryEv,"axG",@progbits,_ZNK5Admin12printSummaryEv,comdat
	.size	_ZNK5Admin12printSummaryEv, .-_ZNK5Admin12printSummaryEv
	.section	.rodata
	.align 8
.LC25:
	.string	"\n===== Ticket Officers' Shifts ====="
.LC26:
	.string	". "
.LC27:
	.string	" (Active)"
.LC28:
	.string	""
	.section	.text._ZNK5Admin18showOfficersShiftsEv,"axG",@progbits,_ZNK5Admin18showOfficersShiftsEv,comdat
	.align 2
	.weak	_ZNK5Admin18showOfficersShiftsEv
	.type	_ZNK5Admin18showOfficersShiftsEv, @function
_ZNK5Admin18showOfficersShiftsEv:
.LFB2344:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2344
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -88(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	leaq	.LC25(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB15:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	movq	$0, -72(%rbp)
	jmp	.L100
.L103:
	movq	-72(%rbp), %rax
	addq	$1, %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSolsEm@PLT
	movq	%rax, %rdx
	leaq	.LC26(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rbx
	movq	-88(%rbp), %rax
	leaq	72(%rax), %rdx
	movq	-72(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm
	movq	%rax, %rdx
	leaq	-64(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer7getNameB5cxx11Ev
.LEHE15:
	leaq	-64(%rbp), %rax
	movq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB16:
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	%rax, %rbx
	movq	-88(%rbp), %rax
	leaq	72(%rax), %rdx
	movq	-72(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer8isActiveEv
	testb	%al, %al
	je	.L101
	leaq	.LC27(%rip), %rax
	jmp	.L102
.L101:
	leaq	.LC28(%rip), %rax
.L102:
	movq	%rax, %rsi
	movq	%rbx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE16:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	addq	$1, -72(%rbp)
.L100:
	movq	-88(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	cmpq	%rax, -72(%rbp)
	setb	%al
	testb	%al, %al
	jne	.L103
	jmp	.L107
.L106:
	endbr64
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB17:
	call	_Unwind_Resume@PLT
.LEHE17:
.L107:
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L105
	call	__stack_chk_fail@PLT
.L105:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2344:
	.section	.gcc_except_table._ZNK5Admin18showOfficersShiftsEv,"aG",@progbits,_ZNK5Admin18showOfficersShiftsEv,comdat
.LLSDA2344:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2344-.LLSDACSB2344
.LLSDACSB2344:
	.uleb128 .LEHB15-.LFB2344
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB16-.LFB2344
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L106-.LFB2344
	.uleb128 0
	.uleb128 .LEHB17-.LFB2344
	.uleb128 .LEHE17-.LEHB17
	.uleb128 0
	.uleb128 0
.LLSDACSE2344:
	.section	.text._ZNK5Admin18showOfficersShiftsEv,"axG",@progbits,_ZNK5Admin18showOfficersShiftsEv,comdat
	.size	_ZNK5Admin18showOfficersShiftsEv, .-_ZNK5Admin18showOfficersShiftsEv
	.section	.rodata
	.align 8
.LC29:
	.string	"No officers available to change shift."
.LC30:
	.string	"Current officers:"
	.align 8
.LC31:
	.string	"Enter officer number to activate: "
.LC32:
	.string	"Invalid choice. Try again: "
	.align 8
.LC33:
	.string	"Shift changed. New active officer: "
	.section	.text._ZN5Admin18changeOfficerShiftEv,"axG",@progbits,_ZN5Admin18changeOfficerShiftEv,comdat
	.align 2
	.weak	_ZN5Admin18changeOfficerShiftEv
	.type	_ZN5Admin18changeOfficerShiftEv, @function
_ZN5Admin18changeOfficerShiftEv:
.LFB2345:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2345
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -120(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-120(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv
	testb	%al, %al
	je	.L109
	leaq	.LC29(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB18:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	jmp	.L108
.L109:
	leaq	.LC30(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	movq	$0, -88(%rbp)
	jmp	.L111
.L114:
	movq	-88(%rbp), %rax
	addq	$1, %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSolsEm@PLT
	movq	%rax, %rdx
	leaq	.LC26(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rbx
	movq	-120(%rbp), %rax
	leaq	72(%rax), %rdx
	movq	-88(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	movq	%rax, %rdx
	leaq	-64(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer7getNameB5cxx11Ev
.LEHE18:
	leaq	-64(%rbp), %rax
	movq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB19:
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	%rax, %rbx
	movq	-120(%rbp), %rax
	leaq	72(%rax), %rdx
	movq	-88(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer8isActiveEv
	testb	%al, %al
	je	.L112
	leaq	.LC27(%rip), %rax
	jmp	.L113
.L112:
	leaq	.LC28(%rip), %rax
.L113:
	movq	%rax, %rsi
	movq	%rbx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE19:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	addq	$1, -88(%rbp)
.L111:
	movq	-120(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	cmpq	%rax, -88(%rbp)
	setb	%al
	testb	%al, %al
	jne	.L114
	leaq	.LC31(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB20:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	jmp	.L115
.L119:
	movl	$0, %esi
	leaq	16+_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@PLT
	call	_ZNSt14numeric_limitsIlE3maxEv
	movl	$10, %edx
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEli@PLT
	leaq	.LC32(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.L115:
	leaq	-108(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	subq	$24, %rdx
	movq	(%rdx), %rdx
	addq	%rdx, %rax
	movq	%rax, %rdi
	call	_ZNKSt9basic_iosIcSt11char_traitsIcEEntEv@PLT
	testb	%al, %al
	jne	.L116
	movl	-108(%rbp), %eax
	testl	%eax, %eax
	jle	.L116
	movq	-120(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	movl	%eax, %edx
	movl	-108(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L117
.L116:
	movl	$1, %eax
	jmp	.L118
.L117:
	movl	$0, %eax
.L118:
	testb	%al, %al
	jne	.L119
	movq	-120(%rbp), %rax
	addq	$72, %rax
	movq	%rax, -80(%rbp)
	movq	-80(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	movq	%rax, -104(%rbp)
	movq	-80(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv
	movq	%rax, -96(%rbp)
	jmp	.L120
.L121:
	leaq	-104(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	movq	%rax, -72(%rbp)
	movq	-72(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	_ZN13TicketOfficer9setActiveEb
	leaq	-104(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
.L120:
	leaq	-96(%rbp), %rdx
	leaq	-104(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_
	testb	%al, %al
	jne	.L121
	movq	-120(%rbp), %rax
	leaq	72(%rax), %rdx
	movl	-108(%rbp), %eax
	subl	$1, %eax
	cltq
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	movl	$1, %esi
	movq	%rax, %rdi
	call	_ZN13TicketOfficer9setActiveEb
	leaq	.LC33(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rbx
	movq	-120(%rbp), %rax
	leaq	72(%rax), %rdx
	movl	-108(%rbp), %eax
	subl	$1, %eax
	cltq
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	movq	%rax, %rdx
	leaq	-64(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNK13TicketOfficer7getNameB5cxx11Ev
.LEHE20:
	leaq	-64(%rbp), %rax
	movq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB21:
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE21:
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	jmp	.L108
.L125:
	endbr64
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB22:
	call	_Unwind_Resume@PLT
.L126:
	endbr64
	movq	%rax, %rbx
	leaq	-64(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.LEHE22:
.L108:
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L124
	call	__stack_chk_fail@PLT
.L124:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2345:
	.section	.gcc_except_table._ZN5Admin18changeOfficerShiftEv,"aG",@progbits,_ZN5Admin18changeOfficerShiftEv,comdat
.LLSDA2345:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2345-.LLSDACSB2345
.LLSDACSB2345:
	.uleb128 .LEHB18-.LFB2345
	.uleb128 .LEHE18-.LEHB18
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB19-.LFB2345
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L125-.LFB2345
	.uleb128 0
	.uleb128 .LEHB20-.LFB2345
	.uleb128 .LEHE20-.LEHB20
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB21-.LFB2345
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L126-.LFB2345
	.uleb128 0
	.uleb128 .LEHB22-.LFB2345
	.uleb128 .LEHE22-.LEHB22
	.uleb128 0
	.uleb128 0
.LLSDACSE2345:
	.section	.text._ZN5Admin18changeOfficerShiftEv,"axG",@progbits,_ZN5Admin18changeOfficerShiftEv,comdat
	.size	_ZN5Admin18changeOfficerShiftEv, .-_ZN5Admin18changeOfficerShiftEv
	.section	.text._ZN5AdminD2Ev,"axG",@progbits,_ZN5AdminD5Ev,comdat
	.align 2
	.weak	_ZN5AdminD2Ev
	.type	_ZN5AdminD2Ev, @function
_ZN5AdminD2Ev:
.LFB2348:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV5Admin(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$72, %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EED1Ev
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN6PersonD2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2348:
	.size	_ZN5AdminD2Ev, .-_ZN5AdminD2Ev
	.weak	_ZN5AdminD1Ev
	.set	_ZN5AdminD1Ev,_ZN5AdminD2Ev
	.section	.text._ZN13TicketOfficerD2Ev,"axG",@progbits,_ZN13TicketOfficerD5Ev,comdat
	.align 2
	.weak	_ZN13TicketOfficerD2Ev
	.type	_ZN13TicketOfficerD2Ev, @function
_ZN13TicketOfficerD2Ev:
.LFB2351:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV13TicketOfficer(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN6PersonD2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2351:
	.size	_ZN13TicketOfficerD2Ev, .-_ZN13TicketOfficerD2Ev
	.weak	_ZN13TicketOfficerD1Ev
	.set	_ZN13TicketOfficerD1Ev,_ZN13TicketOfficerD2Ev
	.section	.rodata
	.align 8
.LC34:
	.string	"Enter number of ticket officers: "
	.align 8
.LC35:
	.string	"\n1. Issue Ticket\n2. Print Summary\n3. View Ticket Officers' Shifts\n4. Change Shift\n5. Exit\nChoose an option: "
	.align 8
.LC36:
	.string	"Invalid input! Please enter a number."
	.align 8
.LC37:
	.string	"No active ticket officer! Assign an officer first."
.LC38:
	.string	"Enter customer name: "
	.align 8
.LC39:
	.string	"Enter vehicle type (Motorbike/Car): "
.LC40:
	.string	"Invalid vehicle type!"
.LC41:
	.string	"Customer: "
.LC42:
	.string	" | Vehicle: "
.LC43:
	.string	" | Hours: "
.LC44:
	.string	" | Fee: "
.LC45:
	.string	"Exiting..."
.LC46:
	.string	"Invalid choice! Try again."
	.text
	.globl	main
	.type	main, @function
main:
.LFB2346:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2346
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$352, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN5AdminC1Ev
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
.LEHB23:
	call	_ZN5Admin9inputInfoEv
	leaq	.LC34(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	jmp	.L130
.L134:
	movl	$0, %esi
	leaq	16+_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@PLT
	call	_ZNSt14numeric_limitsIlE3maxEv
	movl	$10, %edx
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEli@PLT
	leaq	.LC4(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.L130:
	leaq	-360(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	subq	$24, %rdx
	movq	(%rdx), %rdx
	addq	%rdx, %rax
	movq	%rax, %rdi
	call	_ZNKSt9basic_iosIcSt11char_traitsIcEEntEv@PLT
	testb	%al, %al
	jne	.L131
	movl	-360(%rbp), %eax
	testl	%eax, %eax
	jg	.L132
.L131:
	movl	$1, %eax
	jmp	.L133
.L132:
	movl	$0, %eax
.L133:
	testb	%al, %al
	jne	.L134
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEv@PLT
	movl	$0, -352(%rbp)
	jmp	.L135
.L136:
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN13TicketOfficerC1Ev
.LEHE23:
	leaq	.LC14(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB24:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
.LEHE24:
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	leaq	-256(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
.LEHB25:
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	leaq	-256(%rbp), %rdx
	leaq	-224(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN13TicketOfficer7setNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	leaq	-224(%rbp), %rdx
	leaq	-144(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN5Admin10addOfficerERK13TicketOfficer
.LEHE25:
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN13TicketOfficerD1Ev
	addl	$1, -352(%rbp)
.L135:
	movl	-360(%rbp), %eax
	cmpl	%eax, -352(%rbp)
	jl	.L136
.L159:
	leaq	.LC35(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB26:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	leaq	-356(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	subq	$24, %rdx
	movq	(%rdx), %rdx
	addq	%rdx, %rax
	movq	%rax, %rdi
	call	_ZNKSt9basic_iosIcSt11char_traitsIcEEntEv@PLT
	testb	%al, %al
	je	.L137
	movl	$0, %esi
	leaq	16+_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@PLT
	call	_ZNSt14numeric_limitsIlE3maxEv
	movl	$10, %edx
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEli@PLT
	leaq	.LC36(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	jmp	.L158
.L137:
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSi6ignoreEv@PLT
	movl	-356(%rbp), %eax
	cmpl	$5, %eax
	ja	.L139
	movl	%eax, %eax
	leaq	0(,%rax,4), %rdx
	leaq	.L141(%rip), %rax
	movl	(%rdx,%rax), %eax
	cltq
	leaq	.L141(%rip), %rdx
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L141:
	.long	.L139-.L141
	.long	.L145-.L141
	.long	.L144-.L141
	.long	.L143-.L141
	.long	.L142-.L141
	.long	.L140-.L141
	.text
.L145:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN5Admin16getActiveOfficerEv
	movq	%rax, -336(%rbp)
	cmpq	$0, -336(%rbp)
	jne	.L146
	leaq	.LC37(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE26:
	jmp	.L158
.L146:
	leaq	-320(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	leaq	.LC38(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB27:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	leaq	-320(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
.LEHE27:
	leaq	-288(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1Ev@PLT
	leaq	.LC39(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB28:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	leaq	-288(%rbp), %rax
	movq	%rax, %rsi
	leaq	_ZSt3cin(%rip), %rax
	movq	%rax, %rdi
	call	_ZSt7getlineIcSt11char_traitsIcESaIcEERSt13basic_istreamIT_T0_ES7_RNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	$0, -344(%rbp)
	leaq	-288(%rbp), %rax
	leaq	.LC8(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	testb	%al, %al
	je	.L148
	movl	$56, %edi
	call	_Znwm@PLT
.LEHE28:
	movq	%rax, %rbx
	movq	%rbx, %rdi
.LEHB29:
	call	_ZN9MotorbikeC1Ev
.LEHE29:
	movq	%rbx, -344(%rbp)
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcEC1Ev@PLT
	leaq	-361(%rbp), %rdx
	leaq	-256(%rbp), %rax
	leaq	.LC8(%rip), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB30:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_
.LEHE30:
	leaq	-256(%rbp), %rdx
	leaq	-144(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	jmp	.L149
.L148:
	leaq	-288(%rbp), %rax
	leaq	.LC12(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	testb	%al, %al
	je	.L150
	movl	$56, %edi
.LEHB31:
	call	_Znwm@PLT
.LEHE31:
	movq	%rax, %rbx
	movq	%rbx, %rdi
.LEHB32:
	call	_ZN3CarC1Ev
.LEHE32:
	movq	%rbx, -344(%rbp)
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcEC1Ev@PLT
	leaq	-361(%rbp), %rdx
	leaq	-224(%rbp), %rax
	leaq	.LC12(%rip), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB33:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_
.LEHE33:
	leaq	-224(%rbp), %rdx
	leaq	-144(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN5Admin20incrementTicketCountERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	jmp	.L149
.L150:
	leaq	.LC40(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
.LEHB34:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	movl	$0, %ebx
	jmp	.L151
.L149:
	movq	-344(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7Vehicle16inputVehicleInfoEv
	movq	-344(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7Vehicle11setExitTimeEv
	movq	-344(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK7Vehicle14calculateHoursEv
	movl	%eax, -348(%rbp)
	movq	-344(%rbp), %rax
	movq	(%rax), %rax
	addq	$16, %rax
	movq	(%rax), %rcx
	movl	-348(%rbp), %edx
	movq	-344(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	*%rcx
	movq	%xmm0, %rax
	movq	%rax, -328(%rbp)
	leaq	.LC41(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	leaq	-320(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	%rax, %rdx
	leaq	.LC42(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rbx
	leaq	-224(%rbp), %rax
	movq	-344(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNK7Vehicle7getTypeB5cxx11Ev
.LEHE34:
	leaq	-224(%rbp), %rax
	movq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB35:
	call	_ZStlsIcSt11char_traitsIcESaIcEERSt13basic_ostreamIT_T0_ES7_RKNSt7__cxx1112basic_stringIS4_S5_T1_EE@PLT
	movq	%rax, %rdx
	leaq	.LC43(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movl	-348(%rbp), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdx
	leaq	.LC44(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	%rax, %rdx
	movq	-328(%rbp), %rax
	movq	%rax, %xmm0
	movq	%rdx, %rdi
	call	_ZNSolsEd@PLT
	movq	%rax, %rdx
	leaq	.LC21(%rip), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE35:
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	-328(%rbp), %rdx
	leaq	-144(%rbp), %rax
	movq	%rdx, %xmm0
	movq	%rax, %rdi
	call	_ZN5Admin13updateRevenueEd
	movq	-344(%rbp), %rax
	testq	%rax, %rax
	je	.L152
	movq	(%rax), %rdx
	addq	$8, %rdx
	movq	(%rdx), %rdx
	movq	%rax, %rdi
	call	*%rdx
.L152:
	movl	$1, %ebx
.L151:
	leaq	-288(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	testl	%ebx, %ebx
	jne	.L153
	movl	$0, %ebx
	jmp	.L154
.L153:
	movl	$1, %ebx
.L154:
	leaq	-320(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	testl	%ebx, %ebx
	jmp	.L159
.L144:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
.LEHB36:
	call	_ZNK5Admin12printSummaryEv
	jmp	.L158
.L143:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK5Admin18showOfficersShiftsEv
	jmp	.L158
.L142:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN5Admin18changeOfficerShiftEv
	jmp	.L158
.L140:
	leaq	.LC45(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
	movl	$0, %ebx
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN5AdminD1Ev
	movl	%ebx, %eax
	movq	-24(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L170
	jmp	.L181
.L139:
	leaq	.LC46(%rip), %rax
	movq	%rax, %rsi
	leaq	_ZSt4cout(%rip), %rax
	movq	%rax, %rdi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@PLT
	movq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GOTPCREL(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSolsEPFRSoS_E@PLT
.LEHE36:
	nop
.L158:
	jmp	.L159
.L173:
	endbr64
	movq	%rax, %rbx
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	jmp	.L161
.L172:
	endbr64
	movq	%rax, %rbx
.L161:
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN13TicketOfficerD1Ev
	jmp	.L162
.L176:
	endbr64
	movq	%rax, %r12
	movl	$56, %esi
	movq	%rbx, %rdi
	call	_ZdlPvm@PLT
	movq	%r12, %rbx
	jmp	.L164
.L177:
	endbr64
	movq	%rax, %rbx
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	jmp	.L164
.L178:
	endbr64
	movq	%rax, %r12
	movl	$56, %esi
	movq	%rbx, %rdi
	call	_ZdlPvm@PLT
	movq	%r12, %rbx
	jmp	.L164
.L179:
	endbr64
	movq	%rax, %rbx
	leaq	-361(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED1Ev@PLT
	jmp	.L164
.L180:
	endbr64
	movq	%rax, %rbx
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	jmp	.L164
.L175:
	endbr64
	movq	%rax, %rbx
.L164:
	leaq	-288(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	jmp	.L169
.L174:
	endbr64
	movq	%rax, %rbx
.L169:
	leaq	-320(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	jmp	.L162
.L171:
	endbr64
	movq	%rax, %rbx
.L162:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN5AdminD1Ev
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB37:
	call	_Unwind_Resume@PLT
.LEHE37:
.L181:
	call	__stack_chk_fail@PLT
.L170:
	addq	$352, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2346:
	.section	.gcc_except_table,"a",@progbits
.LLSDA2346:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2346-.LLSDACSB2346
.LLSDACSB2346:
	.uleb128 .LEHB23-.LFB2346
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L171-.LFB2346
	.uleb128 0
	.uleb128 .LEHB24-.LFB2346
	.uleb128 .LEHE24-.LEHB24
	.uleb128 .L172-.LFB2346
	.uleb128 0
	.uleb128 .LEHB25-.LFB2346
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L173-.LFB2346
	.uleb128 0
	.uleb128 .LEHB26-.LFB2346
	.uleb128 .LEHE26-.LEHB26
	.uleb128 .L171-.LFB2346
	.uleb128 0
	.uleb128 .LEHB27-.LFB2346
	.uleb128 .LEHE27-.LEHB27
	.uleb128 .L174-.LFB2346
	.uleb128 0
	.uleb128 .LEHB28-.LFB2346
	.uleb128 .LEHE28-.LEHB28
	.uleb128 .L175-.LFB2346
	.uleb128 0
	.uleb128 .LEHB29-.LFB2346
	.uleb128 .LEHE29-.LEHB29
	.uleb128 .L176-.LFB2346
	.uleb128 0
	.uleb128 .LEHB30-.LFB2346
	.uleb128 .LEHE30-.LEHB30
	.uleb128 .L177-.LFB2346
	.uleb128 0
	.uleb128 .LEHB31-.LFB2346
	.uleb128 .LEHE31-.LEHB31
	.uleb128 .L175-.LFB2346
	.uleb128 0
	.uleb128 .LEHB32-.LFB2346
	.uleb128 .LEHE32-.LEHB32
	.uleb128 .L178-.LFB2346
	.uleb128 0
	.uleb128 .LEHB33-.LFB2346
	.uleb128 .LEHE33-.LEHB33
	.uleb128 .L179-.LFB2346
	.uleb128 0
	.uleb128 .LEHB34-.LFB2346
	.uleb128 .LEHE34-.LEHB34
	.uleb128 .L175-.LFB2346
	.uleb128 0
	.uleb128 .LEHB35-.LFB2346
	.uleb128 .LEHE35-.LEHB35
	.uleb128 .L180-.LFB2346
	.uleb128 0
	.uleb128 .LEHB36-.LFB2346
	.uleb128 .LEHE36-.LEHB36
	.uleb128 .L171-.LFB2346
	.uleb128 0
	.uleb128 .LEHB37-.LFB2346
	.uleb128 .LEHE37-.LEHB37
	.uleb128 0
	.uleb128 0
.LLSDACSE2346:
	.text
	.size	main, .-main
	.section	.text._ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_,"axG",@progbits,_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_,comdat
	.weak	_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_
	.type	_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_, @function
_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_:
.LFB2354:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movzbl	(%rax), %edx
	movq	-16(%rbp), %rax
	movzbl	(%rax), %eax
	cmpb	%al, %dl
	sete	%al
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2354:
	.size	_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_, .-_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_
	.section	.text._ZN9__gnu_cxx11char_traitsIcE6lengthEPKc,"axG",@progbits,_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc,comdat
	.align 2
	.weak	_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc
	.type	_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc, @function
_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc:
.LFB2353:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -40(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	$0, -16(%rbp)
	jmp	.L185
.L186:
	addq	$1, -16(%rbp)
.L185:
	movb	$0, -17(%rbp)
	movq	-40(%rbp), %rdx
	movq	-16(%rbp), %rax
	addq	%rax, %rdx
	leaq	-17(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	_ZN9__gnu_cxx11char_traitsIcE2eqERKcS3_
	xorl	$1, %eax
	testb	%al, %al
	jne	.L186
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L188
	call	__stack_chk_fail@PLT
.L188:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2353:
	.size	_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc, .-_ZN9__gnu_cxx11char_traitsIcE6lengthEPKc
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev,"axG",@progbits,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD5Ev,comdat
	.align 2
	.weak	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev
	.type	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev, @function
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev:
.LFB2461:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaIcED2Ev@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2461:
	.size	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev, .-_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev
	.weak	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD1Ev
	.set	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD1Ev,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD2Ev
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC5Ev,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev:
.LFB2629:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSaI13TicketOfficerEC2Ev
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2629:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC1Ev
	.set	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC1Ev,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implC2Ev
	.section	.text._ZNSaI13TicketOfficerED2Ev,"axG",@progbits,_ZNSaI13TicketOfficerED5Ev,comdat
	.align 2
	.weak	_ZNSaI13TicketOfficerED2Ev
	.type	_ZNSaI13TicketOfficerED2Ev, @function
_ZNSaI13TicketOfficerED2Ev:
.LFB2632:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2632:
	.size	_ZNSaI13TicketOfficerED2Ev, .-_ZNSaI13TicketOfficerED2Ev
	.weak	_ZNSaI13TicketOfficerED1Ev
	.set	_ZNSaI13TicketOfficerED1Ev,_ZNSaI13TicketOfficerED2Ev
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED5Ev,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev:
.LFB2635:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2635
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	16(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	%rdx, %rax
	subq	%rcx, %rax
	sarq	$4, %rax
	movq	%rax, %rdx
	movabsq	$-3689348814741910323, %rax
	imulq	%rdx, %rax
	movq	%rax, %rdx
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE12_Vector_implD1Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2635:
	.section	.gcc_except_table
.LLSDA2635:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2635-.LLSDACSB2635
.LLSDACSB2635:
.LLSDACSE2635:
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED5Ev,comdat
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED1Ev
	.set	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED1Ev,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EED5Ev,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev:
.LFB2638:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2638
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	movq	%rax, %rdx
	movq	-8(%rbp), %rax
	movq	8(%rax), %rcx
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EED2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2638:
	.section	.gcc_except_table
.LLSDA2638:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2638-.LLSDACSB2638
.LLSDACSB2638:
.LLSDACSE2638:
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EED5Ev,comdat
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev, .-_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EED1Ev
	.set	_ZNSt6vectorI13TicketOfficerSaIS0_EED1Ev,_ZNSt6vectorI13TicketOfficerSaIS0_EED2Ev
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_:
.LFB2640:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	8(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	16(%rax), %rax
	cmpq	%rax, %rdx
	je	.L195
	movq	-8(%rbp), %rax
	movq	8(%rax), %rcx
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_
	movq	-8(%rbp), %rax
	movq	8(%rax), %rax
	leaq	80(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, 8(%rax)
	jmp	.L197
.L195:
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv
	movq	%rax, %rcx
	movq	-16(%rbp), %rdx
	movq	-8(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
.L197:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2640:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE9push_backERKS0_
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv:
.LFB2642:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	8(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	%rdx, %rax
	subq	%rcx, %rax
	sarq	$4, %rax
	movq	%rax, %rdx
	movabsq	$-3689348814741910323, %rax
	imulq	%rdx, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2642:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EEixEm,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm:
.LFB2643:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	-16(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	addq	%rcx, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2643:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm, .-_ZNSt6vectorI13TicketOfficerSaIS0_EEixEm
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv:
.LFB2644:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-24(%rbp), %rdx
	leaq	-16(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS2_
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L204
	call	__stack_chk_fail@PLT
.L204:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2644:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv:
.LFB2645:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-24(%rbp), %rax
	leaq	8(%rax), %rdx
	leaq	-16(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS2_
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L207
	call	__stack_chk_fail@PLT
.L207:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2645:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE3endEv
	.section	.text._ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_,"axG",@progbits,_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_,comdat
	.weak	_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_
	.type	_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_, @function
_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_:
.LFB2646:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rbx
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rax
	cmpq	%rax, %rbx
	setne	%al
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2646:
	.size	_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_, .-_ZN9__gnu_cxxneIP13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESB_
	.section	.text._ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv,"axG",@progbits,_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv,comdat
	.align 2
	.weak	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
	.type	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv, @function
_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv:
.LFB2647:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	leaq	80(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2647:
	.size	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv, .-_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
	.section	.text._ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv,"axG",@progbits,_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	.type	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv, @function
_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv:
.LFB2648:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2648:
	.size	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv, .-_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv:
.LFB2649:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-24(%rbp), %rdx
	leaq	-16(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS3_
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L216
	call	__stack_chk_fail@PLT
.L216:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2649:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv:
.LFB2650:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-24(%rbp), %rax
	leaq	8(%rax), %rdx
	leaq	-16(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS3_
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L219
	call	__stack_chk_fail@PLT
.L219:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2650:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv
	.section	.text._ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_,"axG",@progbits,_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_,comdat
	.weak	_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	.type	_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_, @function
_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_:
.LFB2651:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rbx
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rax
	cmpq	%rax, %rbx
	setne	%al
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2651:
	.size	_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_, .-_ZN9__gnu_cxxneIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	.section	.text._ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv,"axG",@progbits,_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv,comdat
	.align 2
	.weak	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
	.type	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv, @function
_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv:
.LFB2652:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	leaq	80(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2652:
	.size	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv, .-_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEppEv
	.section	.text._ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv,"axG",@progbits,_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	.type	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv, @function
_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv:
.LFB2653:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2653:
	.size	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv, .-_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEdeEv
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_,"axG",@progbits,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC5IS3_EEPKcRKS3_,comdat
	.align 2
	.weak	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_
	.type	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_, @function
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_:
.LFB2655:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2655
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -56(%rbp)
	movq	%rsi, -64(%rbp)
	movq	%rdx, -72(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-56(%rbp), %rbx
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
.LEHB38:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE13_M_local_dataEv@PLT
	movq	%rax, %rcx
	movq	-72(%rbp), %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	movq	%rbx, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderC1EPcRKS3_@PLT
.LEHE38:
	cmpq	$0, -64(%rbp)
	je	.L227
	movq	-64(%rbp), %rax
	movq	%rax, %rdi
.LEHB39:
	call	_ZNSt11char_traitsIcE6lengthEPKc
	movq	-64(%rbp), %rdx
	addq	%rdx, %rax
	jmp	.L228
.L227:
	movl	$1, %eax
.L228:
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag
.LEHE39:
	jmp	.L232
.L231:
	endbr64
	movq	%rax, %rbx
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderD1Ev
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB40:
	call	_Unwind_Resume@PLT
.LEHE40:
.L232:
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L230
	call	__stack_chk_fail@PLT
.L230:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2655:
	.section	.gcc_except_table
.LLSDA2655:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2655-.LLSDACSB2655
.LLSDACSB2655:
	.uleb128 .LEHB38-.LFB2655
	.uleb128 .LEHE38-.LEHB38
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB39-.LFB2655
	.uleb128 .LEHE39-.LEHB39
	.uleb128 .L231-.LFB2655
	.uleb128 0
	.uleb128 .LEHB40-.LFB2655
	.uleb128 .LEHE40-.LEHB40
	.uleb128 0
	.uleb128 0
.LLSDACSE2655:
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_,"axG",@progbits,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC5IS3_EEPKcRKS3_,comdat
	.size	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_, .-_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_
	.weak	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_
	.set	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2IS3_EEPKcRKS3_
	.section	.text._ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_,"axG",@progbits,_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_,comdat
	.weak	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	.type	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_, @function
_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_:
.LFB2657:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@PLT
	testl	%eax, %eax
	sete	%al
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2657:
	.size	_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_, .-_ZSteqIcSt11char_traitsIcESaIcEEbRKNSt7__cxx1112basic_stringIT_T0_T1_EEPKS5_
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm:
.LFB2659:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	-16(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	addq	%rcx, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2659:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EEixEm
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv:
.LFB2660:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -40(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE3endEv
	movq	%rax, -16(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	movq	%rax, -24(%rbp)
	leaq	-16(%rbp), %rdx
	leaq	-24(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L239
	call	__stack_chk_fail@PLT
.L239:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2660:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE5emptyEv
	.section	.text._ZNSaI13TicketOfficerEC2Ev,"axG",@progbits,_ZNSaI13TicketOfficerEC5Ev,comdat
	.align 2
	.weak	_ZNSaI13TicketOfficerEC2Ev
	.type	_ZNSaI13TicketOfficerEC2Ev, @function
_ZNSaI13TicketOfficerEC2Ev:
.LFB2747:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2747:
	.size	_ZNSaI13TicketOfficerEC2Ev, .-_ZNSaI13TicketOfficerEC2Ev
	.weak	_ZNSaI13TicketOfficerEC1Ev
	.set	_ZNSaI13TicketOfficerEC1Ev,_ZNSaI13TicketOfficerEC2Ev
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC5Ev,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev:
.LFB2750:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	$0, (%rax)
	movq	-8(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-8(%rbp), %rax
	movq	$0, 16(%rax)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2750:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC1Ev
	.set	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC1Ev,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE17_Vector_impl_dataC2Ev
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED5Ev,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev:
.LFB2753:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2753:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED1Ev
	.set	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED1Ev,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerED2Ev
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m:
.LFB2755:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	cmpq	$0, -16(%rbp)
	je	.L245
	movq	-8(%rbp), %rax
	movq	-24(%rbp), %rdx
	movq	-16(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m
.L245:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2755:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv:
.LFB2756:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2756:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	.section	.text._ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E,"axG",@progbits,_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E,comdat
	.weak	_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E
	.type	_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E, @function
_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E:
.LFB2757:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSt8_DestroyIP13TicketOfficerEvT_S2_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2757:
	.size	_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E, .-_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_:
.LFB2758:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE
	movq	%rax, %rdx
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2758:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_
	.section	.rodata
.LC47:
	.string	"vector::_M_realloc_insert"
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,comdat
	.align 2
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_:
.LFB2759:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2759
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -88(%rbp)
	movq	%rsi, -96(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-88(%rbp), %rax
	leaq	.LC47(%rip), %rdx
	movl	$1, %esi
	movq	%rax, %rdi
.LEHB41:
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc
	movq	%rax, -72(%rbp)
	movq	-88(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movq	8(%rax), %rax
	movq	%rax, -56(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE5beginEv
	movq	%rax, -80(%rbp)
	leaq	-80(%rbp), %rdx
	leaq	-96(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_
	movq	%rax, -48(%rbp)
	movq	-88(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm
.LEHE41:
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -32(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE
	movq	%rax, %rsi
	movq	-48(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	movq	%rax, %rdx
	movq	-40(%rbp), %rax
	leaq	(%rdx,%rax), %rcx
	movq	-88(%rbp), %rax
	movq	%rsi, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB42:
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JRKS0_EEEvRS1_PT_DpOT0_
.LEHE42:
	movq	$0, -32(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	movq	%rax, %rbx
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rsi
	movq	-40(%rbp), %rdx
	movq	-64(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_
	movq	%rax, -32(%rbp)
	addq	$80, -32(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	movq	%rax, %rbx
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rax
	movq	-32(%rbp), %rdx
	movq	-56(%rbp), %rsi
	movq	%rbx, %rcx
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_
	movq	%rax, -32(%rbp)
	movq	-88(%rbp), %rax
	movq	-88(%rbp), %rdx
	movq	16(%rdx), %rdx
	subq	-64(%rbp), %rdx
	movq	%rdx, %rcx
	sarq	$4, %rcx
	movabsq	$-3689348814741910323, %rdx
	imulq	%rcx, %rdx
	movq	-64(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB43:
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m
.LEHE43:
	movq	-88(%rbp), %rax
	movq	-40(%rbp), %rdx
	movq	%rdx, (%rax)
	movq	-88(%rbp), %rax
	movq	-32(%rbp), %rdx
	movq	%rdx, 8(%rax)
	movq	-72(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	movq	%rax, %rdx
	movq	-40(%rbp), %rax
	addq	%rax, %rdx
	movq	-88(%rbp), %rax
	movq	%rdx, 16(%rax)
	nop
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L255
	jmp	.L258
.L256:
	endbr64
	movq	%rax, %rdi
	call	__cxa_begin_catch@PLT
	cmpq	$0, -32(%rbp)
	jne	.L252
	movq	-48(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	movq	%rax, %rdx
	movq	-40(%rbp), %rax
	addq	%rax, %rdx
	movq	-88(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_
	jmp	.L253
.L252:
	movq	-88(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	movq	%rax, %rdx
	movq	-32(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
.LEHB44:
	call	_ZSt8_DestroyIP13TicketOfficerS0_EvT_S2_RSaIT0_E
.L253:
	movq	-88(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	-40(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE13_M_deallocateEPS0_m
	call	__cxa_rethrow@PLT
.LEHE44:
.L257:
	endbr64
	movq	%rax, %rbx
	call	__cxa_end_catch@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB45:
	call	_Unwind_Resume@PLT
.LEHE45:
.L258:
	call	__stack_chk_fail@PLT
.L255:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2759:
	.section	.gcc_except_table
	.align 4
.LLSDA2759:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT2759-.LLSDATTD2759
.LLSDATTD2759:
	.byte	0x1
	.uleb128 .LLSDACSE2759-.LLSDACSB2759
.LLSDACSB2759:
	.uleb128 .LEHB41-.LFB2759
	.uleb128 .LEHE41-.LEHB41
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB42-.LFB2759
	.uleb128 .LEHE42-.LEHB42
	.uleb128 .L256-.LFB2759
	.uleb128 0x1
	.uleb128 .LEHB43-.LFB2759
	.uleb128 .LEHE43-.LEHB43
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB44-.LFB2759
	.uleb128 .LEHE44-.LEHB44
	.uleb128 .L257-.LFB2759
	.uleb128 0
	.uleb128 .LEHB45-.LFB2759
	.uleb128 .LEHE45-.LEHB45
	.uleb128 0
	.uleb128 0
.LLSDACSE2759:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT2759:
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,comdat
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.section	.text._ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_,"axG",@progbits,_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC5ERKS2_,comdat
	.align 2
	.weak	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_
	.type	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_, @function
_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_:
.LFB2764:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2764:
	.size	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_, .-_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_
	.weak	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS2_
	.set	_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS2_,_ZN9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS2_
	.section	.text._ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv,"axG",@progbits,_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	.type	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv, @function
_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv:
.LFB2766:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2766:
	.size	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv, .-_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	.section	.text._ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_,"axG",@progbits,_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC5ERKS3_,comdat
	.align 2
	.weak	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_
	.type	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_, @function
_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_:
.LFB2768:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2768:
	.size	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_, .-_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_
	.weak	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS3_
	.set	_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC1ERKS3_,_ZN9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEC2ERKS3_
	.section	.text._ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv,"axG",@progbits,_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	.type	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv, @function
_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv:
.LFB2770:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2770:
	.size	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv, .-_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	.section	.text._ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_,"axG",@progbits,_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_,comdat
	.weak	_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_
	.type	_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_, @function
_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_:
.LFB2772:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	leaq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2772:
	.size	_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_, .-_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_
	.section	.rodata
	.align 8
.LC48:
	.string	"basic_string::_M_construct null not valid"
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag,"axG",@progbits,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag,comdat
	.align 2
	.weak	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag
	.type	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag, @function
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag:
.LFB2771:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2771
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	movq	%rdx, -56(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_
	testb	%al, %al
	je	.L268
	movq	-48(%rbp), %rax
	cmpq	-56(%rbp), %rax
	je	.L268
	movl	$1, %eax
	jmp	.L269
.L268:
	movl	$0, %eax
.L269:
	testb	%al, %al
	je	.L270
	leaq	.LC48(%rip), %rax
	movq	%rax, %rdi
.LEHB46:
	call	_ZSt19__throw_logic_errorPKc@PLT
.L270:
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSt8distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	cmpq	$15, %rax
	jbe	.L271
	leaq	-32(%rbp), %rcx
	movq	-40(%rbp), %rax
	movl	$0, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@PLT
	movq	%rax, %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7_M_dataEPc@PLT
	movq	-32(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_capacityEm@PLT
.LEHE46:
.L271:
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
.LEHB47:
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7_M_dataEv@PLT
.LEHE47:
	movq	%rax, %rcx
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rax
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE13_S_copy_charsEPcPKcS7_@PLT
	movq	-32(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB48:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE13_M_set_lengthEm@PLT
.LEHE48:
	nop
	movq	-24(%rbp), %rax
	subq	%fs:40, %rax
	je	.L274
	jmp	.L277
.L275:
	endbr64
	movq	%rax, %rdi
	call	__cxa_begin_catch@PLT
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
.LEHB49:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
	call	__cxa_rethrow@PLT
.LEHE49:
.L276:
	endbr64
	movq	%rax, %rbx
	call	__cxa_end_catch@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB50:
	call	_Unwind_Resume@PLT
.LEHE50:
.L277:
	call	__stack_chk_fail@PLT
.L274:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2771:
	.section	.gcc_except_table
	.align 4
.LLSDA2771:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT2771-.LLSDATTD2771
.LLSDATTD2771:
	.byte	0x1
	.uleb128 .LLSDACSE2771-.LLSDACSB2771
.LLSDACSB2771:
	.uleb128 .LEHB46-.LFB2771
	.uleb128 .LEHE46-.LEHB46
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB47-.LFB2771
	.uleb128 .LEHE47-.LEHB47
	.uleb128 .L275-.LFB2771
	.uleb128 0x1
	.uleb128 .LEHB48-.LFB2771
	.uleb128 .LEHE48-.LEHB48
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB49-.LFB2771
	.uleb128 .LEHE49-.LEHB49
	.uleb128 .L276-.LFB2771
	.uleb128 0
	.uleb128 .LEHB50-.LFB2771
	.uleb128 .LEHE50-.LEHB50
	.uleb128 0
	.uleb128 0
.LLSDACSE2771:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT2771:
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag,"axG",@progbits,_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag,comdat
	.size	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag, .-_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag
	.section	.text._ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_,"axG",@progbits,_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_,comdat
	.weak	_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	.type	_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_, @function
_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_:
.LFB2773:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rbx
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIPK13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rax
	cmpq	%rax, %rbx
	sete	%al
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2773:
	.size	_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_, .-_ZN9__gnu_cxxeqIPK13TicketOfficerSt6vectorIS1_SaIS1_EEEEbRKNS_17__normal_iteratorIT_T0_EESC_
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC5Ev,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev:
.LFB2813:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2813:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC1Ev
	.set	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC1Ev,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerEC2Ev
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m:
.LFB2815:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-24(%rbp), %rdx
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2815:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE10deallocateERS1_PS0_m
	.section	.text._ZSt8_DestroyIP13TicketOfficerEvT_S2_,"axG",@progbits,_ZSt8_DestroyIP13TicketOfficerEvT_S2_,comdat
	.weak	_ZSt8_DestroyIP13TicketOfficerEvT_S2_
	.type	_ZSt8_DestroyIP13TicketOfficerEvT_S2_, @function
_ZSt8_DestroyIP13TicketOfficerEvT_S2_:
.LFB2816:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2816:
	.size	_ZSt8_DestroyIP13TicketOfficerEvT_S2_, .-_ZSt8_DestroyIP13TicketOfficerEvT_S2_
	.section	.text._ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE,"axG",@progbits,_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE,comdat
	.weak	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE
	.type	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE, @function
_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE:
.LFB2817:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2817:
	.size	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE, .-_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE
	.section	.text._ZN6PersonC2ERKS_,"axG",@progbits,_ZN6PersonC5ERKS_,comdat
	.align 2
	.weak	_ZN6PersonC2ERKS_
	.type	_ZN6PersonC2ERKS_, @function
_ZN6PersonC2ERKS_:
.LFB2821:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2821
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	leaq	16+_ZTV6Person(%rip), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-24(%rbp), %rax
	addq	$8, %rax
	movq	-32(%rbp), %rdx
	addq	$8, %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB51:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1ERKS4_@PLT
.LEHE51:
	movq	-24(%rbp), %rax
	addq	$40, %rax
	movq	-32(%rbp), %rdx
	addq	$40, %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
.LEHB52:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1ERKS4_@PLT
.LEHE52:
	jmp	.L288
.L287:
	endbr64
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED1Ev@PLT
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB53:
	call	_Unwind_Resume@PLT
.LEHE53:
.L288:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2821:
	.section	.gcc_except_table
.LLSDA2821:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2821-.LLSDACSB2821
.LLSDACSB2821:
	.uleb128 .LEHB51-.LFB2821
	.uleb128 .LEHE51-.LEHB51
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB52-.LFB2821
	.uleb128 .LEHE52-.LEHB52
	.uleb128 .L287-.LFB2821
	.uleb128 0
	.uleb128 .LEHB53-.LFB2821
	.uleb128 .LEHE53-.LEHB53
	.uleb128 0
	.uleb128 0
.LLSDACSE2821:
	.section	.text._ZN6PersonC2ERKS_,"axG",@progbits,_ZN6PersonC5ERKS_,comdat
	.size	_ZN6PersonC2ERKS_, .-_ZN6PersonC2ERKS_
	.weak	_ZN6PersonC1ERKS_
	.set	_ZN6PersonC1ERKS_,_ZN6PersonC2ERKS_
	.section	.text._ZN13TicketOfficerC2ERKS_,"axG",@progbits,_ZN13TicketOfficerC5ERKS_,comdat
	.align 2
	.weak	_ZN13TicketOfficerC2ERKS_
	.type	_ZN13TicketOfficerC2ERKS_, @function
_ZN13TicketOfficerC2ERKS_:
.LFB2823:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN6PersonC2ERKS_
	leaq	16+_ZTV13TicketOfficer(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-16(%rbp), %rax
	movzbl	72(%rax), %edx
	movq	-8(%rbp), %rax
	movb	%dl, 72(%rax)
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2823:
	.size	_ZN13TicketOfficerC2ERKS_, .-_ZN13TicketOfficerC2ERKS_
	.weak	_ZN13TicketOfficerC1ERKS_
	.set	_ZN13TicketOfficerC1ERKS_,_ZN13TicketOfficerC2ERKS_
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_:
.LFB2818:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA2818
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt7forwardIRK13TicketOfficerEOT_RNSt16remove_referenceIS3_E4typeE
	movq	%rax, %r13
	movq	-48(%rbp), %rbx
	movq	%rbx, %rsi
	movl	$80, %edi
	call	_ZnwmPv
	movq	%rax, %r12
	movq	%r13, %rsi
	movq	%r12, %rdi
.LEHB54:
	call	_ZN13TicketOfficerC1ERKS_
.LEHE54:
	jmp	.L293
.L292:
	endbr64
	movq	%rax, %r13
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	_ZdlPvS_
	movq	%r13, %rax
	movq	%rax, %rdi
.LEHB55:
	call	_Unwind_Resume@PLT
.LEHE55:
.L293:
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2818:
	.section	.gcc_except_table
.LLSDA2818:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2818-.LLSDACSB2818
.LLSDACSB2818:
	.uleb128 .LEHB54-.LFB2818
	.uleb128 .LEHE54-.LEHB54
	.uleb128 .L292-.LFB2818
	.uleb128 0
	.uleb128 .LEHB55-.LFB2818
	.uleb128 .LEHE55-.LEHB55
	.uleb128 0
	.uleb128 0
.LLSDACSE2818:
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_,comdat
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JRKS1_EEEvPT_DpOT0_
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc:
.LFB2825:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -56(%rbp)
	movq	%rsi, -64(%rbp)
	movq	%rdx, -72(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -24(%rbp)
	xorl	%eax, %eax
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv
	movq	%rax, %rbx
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	subq	%rax, %rbx
	movq	%rbx, %rdx
	movq	-64(%rbp), %rax
	cmpq	%rax, %rdx
	setb	%al
	testb	%al, %al
	je	.L295
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
.L295:
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	movq	%rax, %rbx
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	movq	%rax, -40(%rbp)
	leaq	-64(%rbp), %rdx
	leaq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSt3maxImERKT_S2_S2_
	movq	(%rax), %rax
	addq	%rbx, %rax
	movq	%rax, -32(%rbp)
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE4sizeEv
	cmpq	%rax, -32(%rbp)
	jb	.L296
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv
	cmpq	%rax, -32(%rbp)
	jbe	.L297
.L296:
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv
	jmp	.L298
.L297:
	movq	-32(%rbp), %rax
.L298:
	movq	-24(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L300
	call	__stack_chk_fail@PLT
.L300:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2825:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE12_M_check_lenEmPKc
	.section	.text._ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_,"axG",@progbits,_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_,comdat
	.weak	_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_
	.type	_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_, @function
_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_:
.LFB2826:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rbx
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx17__normal_iteratorIP13TicketOfficerSt6vectorIS1_SaIS1_EEE4baseEv
	movq	(%rax), %rdx
	movq	%rbx, %rax
	subq	%rdx, %rax
	sarq	$4, %rax
	movq	%rax, %rdx
	movabsq	$-3689348814741910323, %rax
	imulq	%rdx, %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2826:
	.size	_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_, .-_ZN9__gnu_cxxmiIP13TicketOfficerSt6vectorIS1_SaIS1_EEEENS_17__normal_iteratorIT_T0_E15difference_typeERKS9_SC_
	.section	.text._ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm,"axG",@progbits,_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm,comdat
	.align 2
	.weak	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm
	.type	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm, @function
_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm:
.LFB2827:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	cmpq	$0, -16(%rbp)
	je	.L304
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m
	jmp	.L306
.L304:
	movl	$0, %eax
.L306:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2827:
	.size	_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm, .-_ZNSt12_Vector_baseI13TicketOfficerSaIS0_EE11_M_allocateEm
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_,comdat
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_:
.LFB2828:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	%rcx, -32(%rbp)
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rdx
	movq	-16(%rbp), %rsi
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2828:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_relocateEPS0_S3_S3_RS1_
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_:
.LFB2829:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2829:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_
	.section	.text._ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_,"axG",@progbits,_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_,comdat
	.weak	_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_
	.type	_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_, @function
_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_:
.LFB2830:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	cmpq	$0, -8(%rbp)
	sete	%al
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2830:
	.size	_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_, .-_ZN9__gnu_cxx17__is_null_pointerIKcEEbPT_
	.section	.text._ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_,"axG",@progbits,_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_,comdat
	.weak	_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_
	.type	_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_, @function
_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_:
.LFB2831:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2831:
	.size	_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_, .-_ZSt19__iterator_categoryIPKcENSt15iterator_traitsIT_E17iterator_categoryERKS3_
	.section	.text._ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag,"axG",@progbits,_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag,comdat
	.weak	_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag
	.type	_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag, @function
_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag:
.LFB2832:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	subq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2832:
	.size	_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag, .-_ZSt10__distanceIPKcENSt15iterator_traitsIT_E15difference_typeES3_S3_St26random_access_iterator_tag
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m:
.LFB2875:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-24(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	movq	%rax, %rdx
	movq	-16(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZdlPvm@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2875:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE10deallocateEPS1_m
	.section	.text._ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_,"axG",@progbits,_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_,comdat
	.weak	_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_
	.type	_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_, @function
_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_:
.LFB2876:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	jmp	.L319
.L320:
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt11__addressofI13TicketOfficerEPT_RS1_
	movq	%rax, %rdi
	call	_ZSt8_DestroyI13TicketOfficerEvPT_
	addq	$80, -8(%rbp)
.L319:
	movq	-8(%rbp), %rax
	cmpq	-16(%rbp), %rax
	jne	.L320
	nop
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2876:
	.size	_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_, .-_ZNSt12_Destroy_auxILb0EE9__destroyIP13TicketOfficerEEvT_S4_
	.section	.text._ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv,"axG",@progbits,_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv,comdat
	.align 2
	.weak	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv
	.type	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv, @function
_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv:
.LFB2877:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	movq	%rax, %rdi
	call	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2877:
	.size	_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv, .-_ZNKSt6vectorI13TicketOfficerSaIS0_EE8max_sizeEv
	.section	.text._ZSt3maxImERKT_S2_S2_,"axG",@progbits,_ZSt3maxImERKT_S2_S2_,comdat
	.weak	_ZSt3maxImERKT_S2_S2_
	.type	_ZSt3maxImERKT_S2_S2_, @function
_ZSt3maxImERKT_S2_S2_:
.LFB2878:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rdx
	movq	-16(%rbp), %rax
	movq	(%rax), %rax
	cmpq	%rax, %rdx
	jnb	.L324
	movq	-16(%rbp), %rax
	jmp	.L325
.L324:
	movq	-8(%rbp), %rax
.L325:
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2878:
	.size	_ZSt3maxImERKT_S2_S2_, .-_ZSt3maxImERKT_S2_S2_
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m:
.LFB2879:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movl	$0, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2879:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE8allocateERS1_m
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE,comdat
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE:
.LFB2880:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	%rcx, -32(%rbp)
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rdx
	movq	-16(%rbp), %rsi
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2880:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE14_S_do_relocateEPS0_S3_S3_RS1_St17integral_constantIbLb1EE
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_:
.LFB2881:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN13TicketOfficerD1Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2881:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE7destroyIS1_EEvPT_
	.section	.text._ZSt11__addressofI13TicketOfficerEPT_RS1_,"axG",@progbits,_ZSt11__addressofI13TicketOfficerEPT_RS1_,comdat
	.weak	_ZSt11__addressofI13TicketOfficerEPT_RS1_
	.type	_ZSt11__addressofI13TicketOfficerEPT_RS1_, @function
_ZSt11__addressofI13TicketOfficerEPT_RS1_:
.LFB2925:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2925:
	.size	_ZSt11__addressofI13TicketOfficerEPT_RS1_, .-_ZSt11__addressofI13TicketOfficerEPT_RS1_
	.section	.text._ZSt8_DestroyI13TicketOfficerEvPT_,"axG",@progbits,_ZSt8_DestroyI13TicketOfficerEvPT_,comdat
	.weak	_ZSt8_DestroyI13TicketOfficerEvPT_
	.type	_ZSt8_DestroyI13TicketOfficerEvPT_, @function
_ZSt8_DestroyI13TicketOfficerEvPT_:
.LFB2926:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN13TicketOfficerD1Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2926:
	.size	_ZSt8_DestroyI13TicketOfficerEvPT_, .-_ZSt8_DestroyI13TicketOfficerEvPT_
	.section	.text._ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_,"axG",@progbits,_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_,comdat
	.weak	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_
	.type	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_, @function
_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_:
.LFB2927:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -40(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movabsq	$115292150460684697, %rax
	movq	%rax, -24(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_
	movq	%rax, -16(%rbp)
	leaq	-16(%rbp), %rdx
	leaq	-24(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZSt3minImERKT_S2_S2_
	movq	(%rax), %rax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L336
	call	__stack_chk_fail@PLT
.L336:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2927:
	.size	_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_, .-_ZNSt6vectorI13TicketOfficerSaIS0_EE11_S_max_sizeERKS1_
	.section	.text._ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv,"axG",@progbits,_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv,comdat
	.align 2
	.weak	_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	.type	_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv, @function
_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv:
.LFB2928:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2928:
	.size	_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv, .-_ZNKSt12_Vector_baseI13TicketOfficerSaIS0_EE19_M_get_Tp_allocatorEv
	.section	.text._ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv,"axG",@progbits,_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv
	.type	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv, @function
_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv:
.LFB2930:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movabsq	$115292150460684697, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2930:
	.size	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv, .-_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv:
.LFB2929:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv
	cmpq	%rax, -16(%rbp)
	seta	%al
	movzbl	%al, %eax
	testq	%rax, %rax
	setne	%al
	testb	%al, %al
	je	.L342
	movabsq	$230584300921369395, %rax
	cmpq	%rax, -16(%rbp)
	jbe	.L343
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.L343:
	call	_ZSt17__throw_bad_allocv@PLT
.L342:
	movq	-16(%rbp), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$4, %rax
	movq	%rax, %rdi
	call	_Znwm@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2929:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE8allocateEmPKv
	.section	.text._ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_,"axG",@progbits,_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_,comdat
	.weak	_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	.type	_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_, @function
_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_:
.LFB2931:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rdx, -40(%rbp)
	movq	%rcx, -48(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt12__niter_baseIP13TicketOfficerET_S2_
	movq	%rax, %r12
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt12__niter_baseIP13TicketOfficerET_S2_
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt12__niter_baseIP13TicketOfficerET_S2_
	movq	%rax, %rdi
	movq	-48(%rbp), %rax
	movq	%rax, %rcx
	movq	%r12, %rdx
	movq	%rbx, %rsi
	call	_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2931:
	.size	_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_, .-_ZSt12__relocate_aIP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_:
.LFB2951:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2951:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE8max_sizeERKS1_
	.section	.text._ZSt3minImERKT_S2_S2_,"axG",@progbits,_ZSt3minImERKT_S2_S2_,comdat
	.weak	_ZSt3minImERKT_S2_S2_
	.type	_ZSt3minImERKT_S2_S2_, @function
_ZSt3minImERKT_S2_S2_:
.LFB2952:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	cmpq	%rax, %rdx
	jnb	.L350
	movq	-16(%rbp), %rax
	jmp	.L351
.L350:
	movq	-8(%rbp), %rax
.L351:
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2952:
	.size	_ZSt3minImERKT_S2_S2_, .-_ZSt3minImERKT_S2_S2_
	.section	.text._ZSt12__niter_baseIP13TicketOfficerET_S2_,"axG",@progbits,_ZSt12__niter_baseIP13TicketOfficerET_S2_,comdat
	.weak	_ZSt12__niter_baseIP13TicketOfficerET_S2_
	.type	_ZSt12__niter_baseIP13TicketOfficerET_S2_, @function
_ZSt12__niter_baseIP13TicketOfficerET_S2_:
.LFB2953:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2953:
	.size	_ZSt12__niter_baseIP13TicketOfficerET_S2_, .-_ZSt12__niter_baseIP13TicketOfficerET_S2_
	.section	.text._ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_,"axG",@progbits,_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_,comdat
	.weak	_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	.type	_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_, @function
_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_:
.LFB2954:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	movq	%rdx, -56(%rbp)
	movq	%rcx, -64(%rbp)
	movq	-56(%rbp), %rax
	movq	%rax, -24(%rbp)
	jmp	.L355
.L356:
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt11__addressofI13TicketOfficerEPT_RS1_
	movq	%rax, %rbx
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt11__addressofI13TicketOfficerEPT_RS1_
	movq	%rax, %rcx
	movq	-64(%rbp), %rax
	movq	%rax, %rdx
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	call	_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_
	addq	$80, -40(%rbp)
	addq	$80, -24(%rbp)
.L355:
	movq	-40(%rbp), %rax
	cmpq	-48(%rbp), %rax
	jne	.L356
	movq	-24(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2954:
	.size	_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_, .-_ZSt14__relocate_a_1IP13TicketOfficerS1_SaIS0_EET0_T_S4_S3_RT1_
	.section	.text._ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv,"axG",@progbits,_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv,comdat
	.align 2
	.weak	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv
	.type	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv, @function
_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv:
.LFB2966:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE11_M_max_sizeEv
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2966:
	.size	_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv, .-_ZNK9__gnu_cxx13new_allocatorI13TicketOfficerE8max_sizeEv
	.section	.text._ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_,"axG",@progbits,_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_,comdat
	.weak	_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_
	.type	_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_, @function
_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_:
.LFB2967:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_
	movq	%rax, %rdx
	movq	-8(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt11__addressofI13TicketOfficerEPT_RS1_
	movq	%rax, %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt16allocator_traitsISaI13TicketOfficerEE7destroyIS0_EEvRS1_PT_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2967:
	.size	_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_, .-_ZSt19__relocate_object_aI13TicketOfficerS0_SaIS0_EEvPT_PT0_RT1_
	.section	.text._ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_,"axG",@progbits,_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_,comdat
	.weak	_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_
	.type	_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_, @function
_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_:
.LFB2970:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2970:
	.size	_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_, .-_ZSt4moveIR13TicketOfficerEONSt16remove_referenceIT_E4typeEOS3_
	.section	.text._ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_,"axG",@progbits,_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_,comdat
	.weak	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_
	.type	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_, @function
_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_:
.LFB2971:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE
	movq	%rax, %rdx
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2971:
	.size	_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_, .-_ZNSt16allocator_traitsISaI13TicketOfficerEE9constructIS0_JS0_EEEvRS1_PT_DpOT0_
	.section	.text._ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE,"axG",@progbits,_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE,comdat
	.weak	_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE
	.type	_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE, @function
_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE:
.LFB2972:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2972:
	.size	_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE, .-_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE
	.section	.text._ZN6PersonC2EOS_,"axG",@progbits,_ZN6PersonC5EOS_,comdat
	.align 2
	.weak	_ZN6PersonC2EOS_
	.type	_ZN6PersonC2EOS_, @function
_ZN6PersonC2EOS_:
.LFB2976:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	leaq	16+_ZTV6Person(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	addq	$8, %rax
	movq	-16(%rbp), %rdx
	addq	$8, %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1EOS4_@PLT
	movq	-8(%rbp), %rax
	addq	$40, %rax
	movq	-16(%rbp), %rdx
	addq	$40, %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1EOS4_@PLT
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2976:
	.size	_ZN6PersonC2EOS_, .-_ZN6PersonC2EOS_
	.weak	_ZN6PersonC1EOS_
	.set	_ZN6PersonC1EOS_,_ZN6PersonC2EOS_
	.section	.text._ZN13TicketOfficerC2EOS_,"axG",@progbits,_ZN13TicketOfficerC5EOS_,comdat
	.align 2
	.weak	_ZN13TicketOfficerC2EOS_
	.type	_ZN13TicketOfficerC2EOS_, @function
_ZN13TicketOfficerC2EOS_:
.LFB2978:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	_ZN6PersonC2EOS_
	leaq	16+_ZTV13TicketOfficer(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-16(%rbp), %rax
	movzbl	72(%rax), %edx
	movq	-8(%rbp), %rax
	movb	%dl, 72(%rax)
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2978:
	.size	_ZN13TicketOfficerC2EOS_, .-_ZN13TicketOfficerC2EOS_
	.weak	_ZN13TicketOfficerC1EOS_
	.set	_ZN13TicketOfficerC1EOS_,_ZN13TicketOfficerC2EOS_
	.section	.text._ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_,"axG",@progbits,_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_,comdat
	.align 2
	.weak	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_
	.type	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_, @function
_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_:
.LFB2973:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rdx, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	_ZSt7forwardI13TicketOfficerEOT_RNSt16remove_referenceIS1_E4typeE
	movq	%rax, %rbx
	movq	-32(%rbp), %rax
	movq	%rax, %rsi
	movl	$80, %edi
	call	_ZnwmPv
	movq	%rbx, %rsi
	movq	%rax, %rdi
	call	_ZN13TicketOfficerC1EOS_
	nop
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2973:
	.size	_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_, .-_ZN9__gnu_cxx13new_allocatorI13TicketOfficerE9constructIS1_JS1_EEEvPT_DpOT0_
	.weak	_ZTV5Admin
	.section	.data.rel.ro.local._ZTV5Admin,"awG",@progbits,_ZTV5Admin,comdat
	.align 8
	.type	_ZTV5Admin, @object
	.size	_ZTV5Admin, 32
_ZTV5Admin:
	.quad	0
	.quad	_ZTI5Admin
	.quad	_ZN5Admin9inputInfoEv
	.quad	_ZN6Person11displayInfoEv
	.weak	_ZTV13TicketOfficer
	.section	.data.rel.ro.local._ZTV13TicketOfficer,"awG",@progbits,_ZTV13TicketOfficer,comdat
	.align 8
	.type	_ZTV13TicketOfficer, @object
	.size	_ZTV13TicketOfficer, 32
_ZTV13TicketOfficer:
	.quad	0
	.quad	_ZTI13TicketOfficer
	.quad	_ZN13TicketOfficer9inputInfoEv
	.quad	_ZN6Person11displayInfoEv
	.weak	_ZTV3Car
	.section	.data.rel.ro.local._ZTV3Car,"awG",@progbits,_ZTV3Car,comdat
	.align 8
	.type	_ZTV3Car, @object
	.size	_ZTV3Car, 40
_ZTV3Car:
	.quad	0
	.quad	_ZTI3Car
	.quad	_ZN3CarD1Ev
	.quad	_ZN3CarD0Ev
	.quad	_ZN3Car12calculateFeeEi
	.section	.text._ZN3CarD2Ev,"axG",@progbits,_ZN3CarD5Ev,comdat
	.align 2
	.weak	_ZN3CarD2Ev
	.type	_ZN3CarD2Ev, @function
_ZN3CarD2Ev:
.LFB2981:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV3Car(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleD2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2981:
	.size	_ZN3CarD2Ev, .-_ZN3CarD2Ev
	.weak	_ZN3CarD1Ev
	.set	_ZN3CarD1Ev,_ZN3CarD2Ev
	.section	.text._ZN3CarD0Ev,"axG",@progbits,_ZN3CarD5Ev,comdat
	.align 2
	.weak	_ZN3CarD0Ev
	.type	_ZN3CarD0Ev, @function
_ZN3CarD0Ev:
.LFB2983:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN3CarD1Ev
	movq	-8(%rbp), %rax
	movl	$56, %esi
	movq	%rax, %rdi
	call	_ZdlPvm@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2983:
	.size	_ZN3CarD0Ev, .-_ZN3CarD0Ev
	.weak	_ZTV9Motorbike
	.section	.data.rel.ro.local._ZTV9Motorbike,"awG",@progbits,_ZTV9Motorbike,comdat
	.align 8
	.type	_ZTV9Motorbike, @object
	.size	_ZTV9Motorbike, 40
_ZTV9Motorbike:
	.quad	0
	.quad	_ZTI9Motorbike
	.quad	_ZN9MotorbikeD1Ev
	.quad	_ZN9MotorbikeD0Ev
	.quad	_ZN9Motorbike12calculateFeeEi
	.section	.text._ZN9MotorbikeD2Ev,"axG",@progbits,_ZN9MotorbikeD5Ev,comdat
	.align 2
	.weak	_ZN9MotorbikeD2Ev
	.type	_ZN9MotorbikeD2Ev, @function
_ZN9MotorbikeD2Ev:
.LFB2985:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	leaq	16+_ZTV9Motorbike(%rip), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, (%rax)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN7VehicleD2Ev
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2985:
	.size	_ZN9MotorbikeD2Ev, .-_ZN9MotorbikeD2Ev
	.weak	_ZN9MotorbikeD1Ev
	.set	_ZN9MotorbikeD1Ev,_ZN9MotorbikeD2Ev
	.section	.text._ZN9MotorbikeD0Ev,"axG",@progbits,_ZN9MotorbikeD5Ev,comdat
	.align 2
	.weak	_ZN9MotorbikeD0Ev
	.type	_ZN9MotorbikeD0Ev, @function
_ZN9MotorbikeD0Ev:
.LFB2987:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	_ZN9MotorbikeD1Ev
	movq	-8(%rbp), %rax
	movl	$56, %esi
	movq	%rax, %rdi
	call	_ZdlPvm@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2987:
	.size	_ZN9MotorbikeD0Ev, .-_ZN9MotorbikeD0Ev
	.weak	_ZTV7Vehicle
	.section	.data.rel.ro._ZTV7Vehicle,"awG",@progbits,_ZTV7Vehicle,comdat
	.align 8
	.type	_ZTV7Vehicle, @object
	.size	_ZTV7Vehicle, 40
_ZTV7Vehicle:
	.quad	0
	.quad	_ZTI7Vehicle
	.quad	0
	.quad	0
	.quad	__cxa_pure_virtual
	.weak	_ZTV6Person
	.section	.data.rel.ro.local._ZTV6Person,"awG",@progbits,_ZTV6Person,comdat
	.align 8
	.type	_ZTV6Person, @object
	.size	_ZTV6Person, 32
_ZTV6Person:
	.quad	0
	.quad	_ZTI6Person
	.quad	_ZN6Person9inputInfoEv
	.quad	_ZN6Person11displayInfoEv
	.weak	_ZTI5Admin
	.section	.data.rel.ro._ZTI5Admin,"awG",@progbits,_ZTI5Admin,comdat
	.align 8
	.type	_ZTI5Admin, @object
	.size	_ZTI5Admin, 24
_ZTI5Admin:
	.quad	_ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	_ZTS5Admin
	.quad	_ZTI6Person
	.weak	_ZTS5Admin
	.section	.rodata._ZTS5Admin,"aG",@progbits,_ZTS5Admin,comdat
	.type	_ZTS5Admin, @object
	.size	_ZTS5Admin, 7
_ZTS5Admin:
	.string	"5Admin"
	.weak	_ZTI13TicketOfficer
	.section	.data.rel.ro._ZTI13TicketOfficer,"awG",@progbits,_ZTI13TicketOfficer,comdat
	.align 8
	.type	_ZTI13TicketOfficer, @object
	.size	_ZTI13TicketOfficer, 24
_ZTI13TicketOfficer:
	.quad	_ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	_ZTS13TicketOfficer
	.quad	_ZTI6Person
	.weak	_ZTS13TicketOfficer
	.section	.rodata._ZTS13TicketOfficer,"aG",@progbits,_ZTS13TicketOfficer,comdat
	.align 16
	.type	_ZTS13TicketOfficer, @object
	.size	_ZTS13TicketOfficer, 16
_ZTS13TicketOfficer:
	.string	"13TicketOfficer"
	.weak	_ZTI3Car
	.section	.data.rel.ro._ZTI3Car,"awG",@progbits,_ZTI3Car,comdat
	.align 8
	.type	_ZTI3Car, @object
	.size	_ZTI3Car, 24
_ZTI3Car:
	.quad	_ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	_ZTS3Car
	.quad	_ZTI7Vehicle
	.weak	_ZTS3Car
	.section	.rodata._ZTS3Car,"aG",@progbits,_ZTS3Car,comdat
	.type	_ZTS3Car, @object
	.size	_ZTS3Car, 5
_ZTS3Car:
	.string	"3Car"
	.weak	_ZTI9Motorbike
	.section	.data.rel.ro._ZTI9Motorbike,"awG",@progbits,_ZTI9Motorbike,comdat
	.align 8
	.type	_ZTI9Motorbike, @object
	.size	_ZTI9Motorbike, 24
_ZTI9Motorbike:
	.quad	_ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	_ZTS9Motorbike
	.quad	_ZTI7Vehicle
	.weak	_ZTS9Motorbike
	.section	.rodata._ZTS9Motorbike,"aG",@progbits,_ZTS9Motorbike,comdat
	.align 8
	.type	_ZTS9Motorbike, @object
	.size	_ZTS9Motorbike, 11
_ZTS9Motorbike:
	.string	"9Motorbike"
	.weak	_ZTI7Vehicle
	.section	.data.rel.ro._ZTI7Vehicle,"awG",@progbits,_ZTI7Vehicle,comdat
	.align 8
	.type	_ZTI7Vehicle, @object
	.size	_ZTI7Vehicle, 16
_ZTI7Vehicle:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTS7Vehicle
	.weak	_ZTS7Vehicle
	.section	.rodata._ZTS7Vehicle,"aG",@progbits,_ZTS7Vehicle,comdat
	.align 8
	.type	_ZTS7Vehicle, @object
	.size	_ZTS7Vehicle, 9
_ZTS7Vehicle:
	.string	"7Vehicle"
	.weak	_ZTI6Person
	.section	.data.rel.ro._ZTI6Person,"awG",@progbits,_ZTI6Person,comdat
	.align 8
	.type	_ZTI6Person, @object
	.size	_ZTI6Person, 16
_ZTI6Person:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTS6Person
	.weak	_ZTS6Person
	.section	.rodata._ZTS6Person,"aG",@progbits,_ZTS6Person,comdat
	.align 8
	.type	_ZTS6Person, @object
	.size	_ZTS6Person, 8
_ZTS6Person:
	.string	"6Person"
	.text
	.type	_Z41__static_initialization_and_destruction_0ii, @function
_Z41__static_initialization_and_destruction_0ii:
.LFB2988:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movl	%edi, -4(%rbp)
	movl	%esi, -8(%rbp)
	cmpl	$1, -4(%rbp)
	jne	.L375
	cmpl	$65535, -8(%rbp)
	jne	.L375
	leaq	_ZStL8__ioinit(%rip), %rax
	movq	%rax, %rdi
	call	_ZNSt8ios_base4InitC1Ev@PLT
	leaq	__dso_handle(%rip), %rax
	movq	%rax, %rdx
	leaq	_ZStL8__ioinit(%rip), %rax
	movq	%rax, %rsi
	movq	_ZNSt8ios_base4InitD1Ev@GOTPCREL(%rip), %rax
	movq	%rax, %rdi
	call	__cxa_atexit@PLT
.L375:
	nop
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2988:
	.size	_Z41__static_initialization_and_destruction_0ii, .-_Z41__static_initialization_and_destruction_0ii
	.type	_GLOBAL__sub_I_main, @function
_GLOBAL__sub_I_main:
.LFB2989:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	$65535, %esi
	movl	$1, %edi
	call	_Z41__static_initialization_and_destruction_0ii
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2989:
	.size	_GLOBAL__sub_I_main, .-_GLOBAL__sub_I_main
	.section	.init_array,"aw"
	.align 8
	.quad	_GLOBAL__sub_I_main
	.section	.rodata
	.align 8
.LC7:
	.long	0
	.long	1085507584
	.align 8
.LC9:
	.long	0
	.long	1074790400
	.align 8
.LC10:
	.long	0
	.long	1075838976
	.align 8
.LC11:
	.long	0
	.long	1086556160
	.weak	__cxa_pure_virtual
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.rel.local.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align 8
	.type	DW.ref.__gxx_personality_v0, @object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.hidden	__dso_handle
	.ident	"GCC: (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
