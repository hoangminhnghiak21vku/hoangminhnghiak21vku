#include <iostream>
#include <vector>

int average(int a, int b) {
    return (a + b) / 2;
}

float average(float a, float b, float c) {
    return (a + b + c) / 3.0f;
}

double average(double a, double b, double c, double d, double e, double f, double g) {
    return (a + b + c + d + e + f + g) / 7.0;
}

double average(const std::vector<unsigned int>& arr) {
    if (arr.empty()) return 0.0; 
    unsigned long long sum = 0;
    for (unsigned int num : arr) {
        sum += num;
    }
    return static_cast<double>(sum) / arr.size();
}

int main() {
    int a, b;
    std::cout << "Nhap 2 so nguyen: ";
    std::cin >> a >> b;
    std::cout << "Trung binh cong: " << average(a, b) << std::endl;

    float x, y, z;
    std::cout << "Nhap 3 so thuc: ";
    std::cin >> x >> y >> z;
    std::cout << "Trung binh cong: " << average(x, y, z) << std::endl;

    double d1, d2, d3, d4, d5, d6, d7;
    std::cout << "Nhap 7 so double: ";
    std::cin >> d1 >> d2 >> d3 >> d4 >> d5 >> d6 >> d7;
    std::cout << "Trung binh cong: " << average(d1, d2, d3, d4, d5, d6, d7) << std::endl;

    int n;
    std::cout << "Nhap so luong phan tu cua mang: ";
    std::cin >> n;

    if (n <= 0) {
        std::cout << "So luong phan tu khong hop le" << std::endl;
        return 1;
    }

    std::vector<unsigned int> arr;
    std::cout << "Nhap " << n << " so nguyen khong am: ";
    for (int i = 0; i < n; i++) {
        int temp;
        while (true) {
            std::cin >> temp;
            if (temp < 0) {
                std::cout << "nhap so khong am: ";
            } else {
                arr.push_back(static_cast<unsigned int>(temp));
                break;
            }
        }
    }

    std::cout << "Trung binh cong: " << average(arr) << std::endl;

    return 0;
}
